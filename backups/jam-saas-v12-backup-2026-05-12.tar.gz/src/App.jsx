import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutDashboard,
  FolderKanban,
  ListChecks,
  Trophy,
  Users,
  Building2,
  FileText,
  Search,
  Filter,
  Plus,
  ChevronDown,
  ChevronRight,
  CalendarDays,
  Dumbbell,
  Goal,
  Waves,
  PersonStanding,
  Volleyball,
  CheckCircle2,
  AlertTriangle,
  Library,
  Clock3,
  BarChart3,
  Edit3,
  Trash2,
  Target,
  Bell,
  Mail,
  Megaphone,
  Send,
  MoreHorizontal,
  Copy,
  X,
  EyeOff,
  Layers,
} from "lucide-react";

const STORAGE_KEY = "jam_saas_v19_clean";

const BASE_SPORTS = [
  { id: "football", name: "Football", icon: Goal },
  { id: "athletisme", name: "Athlétisme", icon: PersonStanding },
  { id: "developpe_couche", name: "Développé couché", icon: Dumbbell },
  { id: "natation", name: "Natation", icon: Waves },
  { id: "volley", name: "Volley", icon: Volleyball },
];

const STATUS_OPTIONS = ["À faire", "En cours", "En attente", "Terminé"];
const PRIORITY_OPTIONS = ["Basse", "Moyenne", "Haute", "Critique"];
const DOC_MODES = ["all", "internal", "external"];
const DOC_STATUS = ["Brouillon", "À valider", "Validé", "Publié", "Archivé"];
const ATHLETE_STATUS = ["Actif", "À relancer", "Blessé", "Absent"];
const CLUB_STATUS = ["À contacter", "Invité", "Inscrit", "Validé"];
const COMM_STATUS = ["Brouillon", "Prêt à envoyer", "Envoyée"];
const CUSTOM_FIELD_TYPES = ["texte", "nombre", "pourcentage", "date", "financier", "statut", "case_a_cocher", "personne"];

const uid = () => crypto.randomUUID();

const seedProjects = [
  {
    id: uid(),
    name: "Challenge National JAM 2026",
    description: "Organisation générale de la compétition.",
    owner: "Samy",
    sport: "developpe_couche",
    status: "En cours",
    priority: "Haute",
    customFieldValues: {},
    startDate: "2026-03-01",
    endDate: "2026-05-30",
    durationDays: 90,
    parentId: null,
    workspaceId: "ws_jam",
  },
  {
    id: uid(),
    name: "Logistique générale",
    description: "Gymnase, matériel, coordination.",
    owner: "Samy",
    sport: "developpe_couche",
    status: "En cours",
    priority: "Haute",
    customFieldValues: {},
    startDate: "2026-03-10",
    endDate: "2026-05-20",
    durationDays: 72,
    parentId: null,
    workspaceId: "ws_jam",
  },
  {
    id: uid(),
    name: "Portail inscriptions clubs",
    description: "Suivi clubs et exports.",
    owner: "Samy",
    sport: "developpe_couche",
    status: "En cours",
    priority: "Haute",
    customFieldValues: {},
    startDate: "2026-03-05",
    endDate: "2026-04-30",
    durationDays: 56,
    parentId: null,
    workspaceId: "ws_jam",
  },
];

const ROOT_ID = seedProjects[0].id;
const LOG_ID = seedProjects[1].id;
const PORTAL_ID = seedProjects[2].id;

const defaultData = {
  workspaces: [
    { id: "ws_jam", name: "JAM", color: "#0f172a", initial: "J" },
    { id: "ws_propcept", name: "Propcept Event", color: "#7c3aed", initial: "P" },
  ],
  currentWorkspaceId: "ws_jam",
  customFields: [
    { id: uid(), name: "Budget prévisionnel", type: "financier", appliesTo: ["projects"], position: "right" },
    { id: uid(), name: "Date comité", type: "date", appliesTo: ["projects", "tasks"], position: "right" },
    { id: uid(), name: "Charge estimée", type: "nombre", appliesTo: ["tasks"], position: "right" },
  ],
  convocations: [
    {
      id: uid(),
      title: "Convocation match U13",
      sport: "football",
      type: "Match",
      date: "2026-04-12",
      time: "14:00",
      location: "Stade municipal",
      recipients: [],
      message: "Merci de vous présenter 45 minutes avant le coup d’envoi.",
      attachmentTitle: "Feuille de match U13",
      status: "Brouillon",
      workspaceId: "ws_jam",
    },
  ],
  notifications: [
    {
      id: uid(),
      title: "Partage feuille d'entraînement",
      sport: "developpe_couche",
      channel: "Email",
      audience: "Groupe sport",
      targetSport: "developpe_couche",
      message: "Nouvelle feuille d'entraînement disponible pour la semaine.",
      attachmentTitle: "Programme semaine force",
      status: "Prêt à envoyer",
      sentAt: "",
      workspaceId: "ws_jam",
    },
  ],
  customSports: [],
  projects: [
    ...seedProjects,
    {
      id: uid(),
      name: "Communication clubs",
      description: "Mails et relances.",
      owner: "Samy",
      sport: "developpe_couche",
      status: "En cours",
      priority: "Moyenne",
      customFieldValues: {},
      startDate: "2026-03-15",
      endDate: "2026-04-15",
      durationDays: 31,
      parentId: ROOT_ID,
      workspaceId: "ws_jam",
    },
    {
      id: uid(),
      name: "Pesée et planning sportif",
      description: "Horaires et flux athlètes.",
      owner: "Samy",
      sport: "developpe_couche",
      status: "À faire",
      priority: "Haute",
      customFieldValues: {},
      startDate: "2026-04-20",
      endDate: "2026-05-15",
      durationDays: 25,
      parentId: ROOT_ID,
      workspaceId: "ws_jam",
    },
    {
      id: uid(),
      name: "Restauration",
      description: "Plateaux repas et régimes.",
      owner: "Samy",
      sport: "developpe_couche",
      status: "À faire",
      priority: "Moyenne",
      customFieldValues: {},
      startDate: "2026-04-01",
      endDate: "2026-05-10",
      durationDays: 39,
      parentId: LOG_ID,
      workspaceId: "ws_jam",
    },
    {
      id: uid(),
      name: "Export inscriptions",
      description: "Contrôle et export CSV.",
      owner: "Samy",
      sport: "developpe_couche",
      status: "En cours",
      priority: "Moyenne",
      customFieldValues: {},
      startDate: "2026-03-20",
      endDate: "2026-04-25",
      durationDays: 36,
      parentId: PORTAL_ID,
      workspaceId: "ws_jam",
    },
  ],
  tasks: [
    {
      id: uid(),
      title: "Envoyer le mail d'ouverture aux clubs",
      description: "Annonce officielle.",
      assignee: "Samy",
      projectId: PORTAL_ID,
      status: "Terminé",
      priority: "Haute",
      customFieldValues: {},
      progress: 100,
      startDate: "2026-03-25",
      endDate: "2026-03-31",
      durationDays: 6,
      workspaceId: "ws_jam",
    },
    {
      id: uid(),
      title: "Préparer la trame des repas",
      description: "Quantités et options.",
      assignee: "Samy",
      projectId: LOG_ID,
      status: "En cours",
      priority: "Moyenne",
      customFieldValues: {},
      progress: 45,
      startDate: "2026-04-10",
      endDate: "2026-04-18",
      durationDays: 8,
      workspaceId: "ws_jam",
    },
    {
      id: uid(),
      title: "Valider la feuille de pesée",
      description: "Version club et arbitres.",
      assignee: "Samy",
      projectId: ROOT_ID,
      status: "À faire",
      priority: "Haute",
      customFieldValues: {},
      progress: 10,
      startDate: "2026-04-15",
      endDate: "2026-04-20",
      durationDays: 5,
      workspaceId: "ws_jam",
    },
  ],
  athletes: [
    { id: uid(), name: "Athlète exemple 1", sport: "developpe_couche", category: "-88 kg", coach: "Coach JAM", email: "", phone: "", status: "Actif", notes: "Suivi force.", workspaceId: "ws_jam" },
    { id: uid(), name: "Athlète exemple 2", sport: "football", category: "U13", coach: "Coach Terrain", email: "", phone: "", status: "À relancer", notes: "Feuille de match.", workspaceId: "ws_jam" },
  ],
  clubs: [
    { id: uid(), name: "JAM", sport: "developpe_couche", city: "Montrouge", contactName: "Samy", email: "", phone: "", delegationSize: "12", status: "Validé", notes: "Club organisateur.", workspaceId: "ws_jam" },
    { id: uid(), name: "Club Exemple Paris", sport: "football", city: "Paris", contactName: "Responsable club", email: "", phone: "", delegationSize: "18", status: "Invité", notes: "À relancer.", workspaceId: "ws_jam" },
  ],
  documents: [
    { id: uid(), sport: "developpe_couche", title: "Feuille d'entraînement type", type: "Suivi sportif", status: "Validé", notes: "Modèle à transmettre.", url: "", content: "Exemple de contenu interne pour suivi sportif.", workspaceId: "ws_jam" },
    { id: uid(), sport: "football", title: "Feuille de match", type: "Match", status: "À valider", notes: "Document joueur.", url: "", content: "Composition, remplaçants, consignes.", workspaceId: "ws_jam" },
    { id: uid(), sport: "developpe_couche", title: "Portail inscriptions", type: "Lien", status: "Publié", notes: "Accès externe au portail.", url: "https://challenge-national-jam.netlify.app/", content: "", workspaceId: "ws_jam" },
  ],
  tableConfig: {
    projects: { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {} },
    tasks: { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {} },
    athletes: { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {} },
    clubs: { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {} },
    documents: { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {} },
  },
};

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultData;
    const parsed = JSON.parse(raw);
    const addWs = (arr) => (arr || []).map((item) => item.workspaceId ? item : { ...item, workspaceId: "ws_jam" });
    const addDocDefaults = (arr) => addWs(arr).map((doc) => ({ status: doc.url ? "Publié" : "Brouillon", ...doc }));
    return {
      ...defaultData,
      ...parsed,
      workspaces: parsed.workspaces || defaultData.workspaces,
      currentWorkspaceId: parsed.currentWorkspaceId || "ws_jam",
      projects: addWs(parsed.projects || defaultData.projects),
      tasks: addWs(parsed.tasks || defaultData.tasks),
      athletes: addWs(parsed.athletes || defaultData.athletes),
      clubs: addWs(parsed.clubs || defaultData.clubs),
      documents: addDocDefaults(parsed.documents || defaultData.documents),
      convocations: addWs(parsed.convocations || defaultData.convocations),
      notifications: addWs(parsed.notifications || defaultData.notifications),
      tableConfig: { ...defaultData.tableConfig, ...(parsed.tableConfig || {}) },
    };
  } catch {
    return defaultData;
  }
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function badgeClass(kind, value) {
  if (kind === "status") {
    if (value === "Terminé") return "bg-green-100 text-green-700 border-green-200";
    if (value === "En cours") return "bg-blue-100 text-blue-700 border-blue-200";
    if (value === "En attente") return "bg-amber-100 text-amber-700 border-amber-200";
    return "bg-slate-100 text-slate-700 border-slate-200";
  }
  if (value === "Critique") return "bg-red-100 text-red-700 border-red-200";
  if (value === "Haute") return "bg-orange-100 text-orange-700 border-orange-200";
  if (value === "Moyenne") return "bg-violet-100 text-violet-700 border-violet-200";
  return "bg-slate-100 text-slate-700 border-slate-200";
}

function progressTone(value) {
  if (value >= 100) return "bg-green-500";
  if (value >= 70) return "bg-blue-500";
  if (value >= 40) return "bg-amber-500";
  return "bg-red-500";
}

function descendants(projectId, projects) {
  const ids = new Set([projectId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const p of projects) {
      if (p.parentId && ids.has(p.parentId) && !ids.has(p.id)) {
        ids.add(p.id);
        changed = true;
      }
    }
  }
  return ids;
}

function clampProgress(value) {
  return Math.max(0, Math.min(100, Number(value) || 0));
}

function normalizeTaskProgress(progress, status) {
  const raw = clampProgress(progress);
  if (status === "Terminé") return 100;
  if (status === "À faire") return raw === 100 ? 0 : raw;
  if (status === "En attente") return raw === 0 ? 5 : Math.min(raw, 95);
  return raw === 0 ? 5 : Math.min(raw, 99);
}

function statusFromProgress(progress, currentStatus) {
  const value = clampProgress(progress);
  if (value >= 100) return "Terminé";
  if (value <= 0) return "À faire";
  if (currentStatus === "En attente") return "En attente";
  return "En cours";
}

function ownProgress(projectId, tasks) {
  const rows = tasks.filter((t) => t.projectId === projectId);
  if (!rows.length) return 0;
  return Math.round(rows.reduce((sum, row) => sum + normalizeTaskProgress(row.progress, row.status), 0) / rows.length);
}

function consolidatedProgress(projectId, tasks, projects) {
  const ids = descendants(projectId, projects);
  const rows = tasks.filter((t) => ids.has(t.projectId));
  if (!rows.length) return 0;
  return Math.round(rows.reduce((sum, row) => sum + normalizeTaskProgress(row.progress, row.status), 0) / rows.length);
}

function deriveProjectStatus(progress, currentStatus) {
  if (progress >= 100) return "Terminé";
  if (progress <= 0) return "À faire";
  if (currentStatus === "En attente") return "En attente";
  return "En cours";
}

function buildTree(projects) {
  const map = new Map(projects.map((p) => [p.id, { ...p, children: [] }]));
  const roots = [];
  map.forEach((p) => {
    if (p.parentId && map.has(p.parentId)) map.get(p.parentId).children.push(p);
    else roots.push(p);
  });
  return roots;
}

function levelOf(projectId, projects) {
  const map = new Map(projects.map((p) => [p.id, p]));
  let level = 0;
  let cur = map.get(projectId);
  while (cur?.parentId && map.has(cur.parentId)) {
    level += 1;
    cur = map.get(cur.parentId);
  }
  return level + 1;
}

function daysBetween(startDate, endDate) {
  if (!startDate || !endDate) return "—";
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diff = Math.round((end - start) / (1000 * 60 * 60 * 24));
  return Number.isFinite(diff) ? diff : "—";
}

function formatCustomFieldValue(type, value) {
  if (value === undefined || value === null || value === "") return "—";
  if (type === "financier") {
    const num = Number(value);
    return Number.isFinite(num) ? new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(num) : value;
  }
  if (type === "nombre") {
    const num = Number(value);
    return Number.isFinite(num) ? new Intl.NumberFormat("fr-FR").format(num) : value;
  }
  if (type === "pourcentage") {
    const num = Number(value);
    return Number.isFinite(num) ? `${new Intl.NumberFormat("fr-FR").format(num)} %` : value;
  }
  if (type === "case_a_cocher") return value ? "Oui" : "Non";
  return value;
}

function tableColumnsToFields(cols = [], appliesTo = []) {
  return (cols || []).map((col) => ({
    id: col.key,
    name: col.label,
    type: col.type,
    appliesTo,
    source: "table",
  }));
}

function mergeCustomFields(...groups) {
  const seen = new Set();
  return groups.flat().filter((field) => {
    if (!field?.id || seen.has(field.id)) return false;
    seen.add(field.id);
    return true;
  });
}

function makeSportId(name) {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function Card({ children, className = "" }) {
  return <div className={`bg-white rounded-3xl shadow-sm ${className}`}>{children}</div>;
}

function Badge({ children, className = "" }) {
  return <span className={`text-xs px-2 py-1 rounded-full border ${className}`}>{children}</span>;
}

function ProgressBar({ value, label }) {
  return (
    <div>
      <div className="flex justify-between text-xs text-slate-500 mb-1">
        <span>{label}</span>
        <span>{value}%</span>
      </div>
      <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
        <div className={`h-full rounded-full ${progressTone(value)}`} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function ViewToggle({ options, value, onChange }) {
  return (
    <div className="flex rounded-2xl border bg-white p-1 gap-1">
      {options.map(({ id, label, Icon }) => (
        <button
          key={id}
          type="button"
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-colors ${value === id ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"}`}
        >
          <Icon className="w-4 h-4" /> {label}
        </button>
      ))}
    </div>
  );
}

function KanbanBoard({ rows, statuses, getStatus = (row) => row.status, onStatusChange, renderCard, emptyLabel = "Aucun élément." }) {
  const [dragId, setDragId] = useState(null);
  const normalizedStatus = (row) => {
    const value = getStatus(row);
    return statuses.includes(value) ? value : statuses[0];
  };

  if (!rows.length) return <p className="text-center text-slate-500 py-12">{emptyLabel}</p>;

  return (
    <div className="overflow-x-auto pb-3">
      <div className="grid auto-cols-[minmax(260px,1fr)] grid-flow-col gap-4 min-w-full">
        {statuses.map((status) => {
          const items = rows.filter((row) => normalizedStatus(row) === status);
          return (
            <section
              key={status}
              className="min-h-[360px] rounded-2xl border bg-slate-100/70 p-3"
              onDragOver={(e) => onStatusChange && e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (dragId && onStatusChange) onStatusChange(dragId, status);
                setDragId(null);
              }}
            >
              <div className="flex items-center justify-between gap-3 mb-3">
                <h2 className="text-sm font-bold text-slate-800">{status}</h2>
                <Badge className="bg-white text-slate-600 border-slate-200">{items.length}</Badge>
              </div>
              <div className="space-y-3">
                {items.map((row) => (
                  <div
                    key={row.id}
                    draggable={Boolean(onStatusChange)}
                    onDragStart={() => setDragId(row.id)}
                    onDragEnd={() => setDragId(null)}
                    className="rounded-2xl border bg-white p-4 shadow-sm cursor-grab active:cursor-grabbing"
                  >
                    {renderCard(row)}
                  </div>
                ))}
                {!items.length && (
                  <div className="rounded-2xl border border-dashed bg-white/60 p-4 text-center text-xs text-slate-400">
                    Dépose ici
                  </div>
                )}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function StatCard({ title, value, subtitle, Icon }) {
  return (
    <Card className="p-5 rounded-2xl">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-500">{title}</p>
          <p className="text-3xl font-semibold mt-2">{value}</p>
          <p className="text-xs text-slate-500 mt-2">{subtitle}</p>
        </div>
        <div className="p-3 rounded-2xl bg-slate-100"><Icon className="w-5 h-5 text-slate-700" /></div>
      </div>
    </Card>
  );
}

function Modal({ open, title, children, onClose, onSave, saveLabel = "Enregistrer" }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl p-6 max-h-[92vh] overflow-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">{title}</h3>
          <button onClick={onClose} className="text-slate-500 text-xl">✕</button>
        </div>
        {children}
        <div className="flex justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-4 py-2 rounded-2xl border">Annuler</button>
          <button onClick={onSave} className="px-4 py-2 rounded-2xl bg-slate-900 text-white">{saveLabel}</button>
        </div>
      </div>
    </div>
  );
}

function CustomFieldsEditor({ fields, values, onChange }) {
  if (!fields.length) {
    return <p className="text-sm text-slate-500">Aucune colonne personnalisée pour ce type d’élément.</p>;
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {fields.map((field) => {
        const value = values?.[field.id] ?? "";
        const isNumeric = field.type === "nombre" || field.type === "financier" || field.type === "pourcentage";
        if (field.type === "case_a_cocher") {
          return (
            <label key={field.id} className="flex items-center gap-3 rounded-2xl border px-4 py-3 bg-white">
              <input type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(field.id, e.target.checked)} />
              <span className="text-sm font-medium text-slate-700">{field.name}</span>
            </label>
          );
        }

        if (field.type === "statut") {
          return (
            <select key={field.id} className="w-full rounded-2xl border px-4 py-3" value={value} onChange={(e) => onChange(field.id, e.target.value)}>
              <option value="">{field.name}</option>
              <option value="À faire">À faire</option>
              <option value="En cours">En cours</option>
              <option value="Bloqué">Bloqué</option>
              <option value="Terminé">Terminé</option>
            </select>
          );
        }

        return (
          <input
            key={field.id}
            type={field.type === "date" ? "date" : isNumeric ? "number" : "text"}
            step={field.type === "financier" ? "0.01" : field.type === "nombre" || field.type === "pourcentage" ? "1" : undefined}
            min={field.type === "pourcentage" ? "0" : undefined}
            max={field.type === "pourcentage" ? "100" : undefined}
            className="w-full rounded-2xl border px-4 py-3"
            placeholder={`${field.name}${field.type === "financier" ? " (€)" : field.type === "pourcentage" ? " (%)" : ""}`}
            value={value}
            onChange={(e) => onChange(field.id, e.target.value)}
          />
        );
      })}
    </div>
  );
}

function ProjectTreeNode({ node, tasks, projects, expanded, setExpanded, onQuickTask, onEditProject, requestDelete, onDuplicate, projectCustomFields }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [menuOpen]);

  const own = node.computedOwnProgress ?? ownProgress(node.id, tasks);
  const total = node.computedTotalProgress ?? consolidatedProgress(node.id, tasks, projects);
  const isOpen = expanded[node.id] ?? true;
  const childCount = node.children.length;
  const directTasks = tasks.filter((t) => t.projectId === node.id);

  return (
    <div className="border rounded-2xl p-4 bg-white shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div className="flex gap-3 flex-1 min-w-0">
          <button onClick={() => setExpanded((prev) => ({ ...prev, [node.id]: !isOpen }))} className="mt-1 text-slate-500 shrink-0">
            {childCount ? (isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />) : <div className="w-4" />}
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-semibold truncate">{node.name}</h3>
              <Badge>Niv. {levelOf(node.id, projects)}</Badge>
              <Badge className={badgeClass("status", node.status)}>{node.status}</Badge>
              <Badge className={badgeClass("priority", node.priority)}>{node.priority}</Badge>
              {node.sportName && <Badge>{node.sportName}</Badge>}
            </div>
            {node.description && <p className="text-sm text-slate-500 mt-1">{node.description}</p>}
            <div className="grid md:grid-cols-2 gap-4 mt-3 max-w-3xl">
              <ProgressBar value={own} label="Progression directe" />
              <ProgressBar value={total} label="Progression consolidée" />
            </div>
            <div className="flex flex-wrap gap-3 text-xs text-slate-500 mt-2">
              {node.owner && <span>Responsable : {node.owner}</span>}
              {node.startDate && <span>Début : {node.startDate}</span>}
              {node.endDate && <span>Fin : {node.endDate}</span>}
              <span>Sous-projets : {childCount}</span>
              <span>Tâches : {directTasks.length}</span>
            </div>

            {projectCustomFields.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {projectCustomFields.map((field) => (
                  <Badge key={field.id}>{field.name} : {formatCustomFieldValue(field.type, node.customFieldValues?.[field.id])}</Badge>
                ))}
              </div>
            )}

            {directTasks.length > 0 && (
              <div className="mt-4 rounded-2xl bg-slate-50 border border-slate-200 p-3">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Tâches ({directTasks.length})</p>
                <div className="space-y-2">
                  {directTasks.map((task) => {
                    const prog = normalizeTaskProgress(task.progress, task.status);
                    return (
                      <div key={task.id} className="rounded-xl border bg-white p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2 min-w-0">
                            <CheckCircle2 className={`w-4 h-4 shrink-0 ${task.status === "Terminé" ? "text-green-500" : "text-slate-300"}`} />
                            <p className="text-sm font-medium text-slate-900 truncate">{task.title}</p>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <Badge className={badgeClass("status", task.status)}>{task.status}</Badge>
                            <Badge className={badgeClass("priority", task.priority)}>{task.priority}</Badge>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 mt-2 pl-6">
                          <span className="text-xs text-slate-500">{task.assignee || "Non assigné"}</span>
                          {task.endDate && <span className="text-xs text-slate-400">· {task.endDate}</span>}
                        </div>
                        <div className="mt-2 pl-6">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 h-1.5 rounded-full bg-slate-200 overflow-hidden">
                              <div className={`h-full rounded-full ${progressTone(prog)}`} style={{ width: `${prog}%` }} />
                            </div>
                            <span className="text-xs font-bold text-slate-600 w-7 text-right">{prog}%</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ··· context menu */}
        <div className="relative shrink-0" ref={menuRef}>
          <button
            onClick={(e) => { e.stopPropagation(); setMenuOpen((v) => !v); }}
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-500"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-full z-40 mt-1 bg-white rounded-xl shadow-xl border py-1 min-w-[180px]">
              <button onClick={() => { onEditProject(node); setMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-slate-400" /> Modifier
              </button>
              <button onClick={() => { onQuickTask(node.id); setMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Plus className="w-4 h-4 text-slate-400" /> Ajouter une tâche
              </button>
              <button onClick={() => { onDuplicate(node); setMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Copy className="w-4 h-4 text-slate-400" /> Dupliquer
              </button>
              <div className="border-t my-1" />
              <button onClick={() => { requestDelete("project", node); setMenuOpen(false); }} className="w-full text-left px-3 py-2 text-sm hover:bg-red-50 text-red-600 flex items-center gap-2">
                <Trash2 className="w-4 h-4" /> Supprimer
              </button>
            </div>
          )}
        </div>
      </div>

      {isOpen && childCount > 0 && (
        <div className="pl-8 mt-4 border-l-2 border-slate-100 space-y-3">
          <ProjectTree nodes={node.children} tasks={tasks} projects={projects} expanded={expanded} setExpanded={setExpanded} onQuickTask={onQuickTask} onEditProject={onEditProject} requestDelete={requestDelete} onDuplicate={onDuplicate} projectCustomFields={projectCustomFields} />
        </div>
      )}
    </div>
  );
}

function ProjectTree({ nodes, tasks, projects, expanded, setExpanded, onQuickTask, onEditProject, requestDelete, onDuplicate, projectCustomFields }) {
  return (
    <div className="space-y-3">
      {nodes.map((node) => (
        <ProjectTreeNode key={node.id} node={node} tasks={tasks} projects={projects} expanded={expanded} setExpanded={setExpanded} onQuickTask={onQuickTask} onEditProject={onEditProject} requestDelete={requestDelete} onDuplicate={onDuplicate} projectCustomFields={projectCustomFields} />
      ))}
    </div>
  );
}

// ===== Generic table column helpers =====
const COL_TYPES = [
  { id: "texte", label: "Texte" },
  { id: "nombre", label: "Nombre" },
  { id: "pourcentage", label: "Pourcentage (%)" },
  { id: "date", label: "Date" },
  { id: "financier", label: "Financier (€)" },
  { id: "statut", label: "Statut" },
  { id: "case_a_cocher", label: "Case à cocher" },
  { id: "personne", label: "Personne" },
];

function passesFilter(value, filter, type) {
  if (!filter || filter.value === undefined || filter.value === null || filter.value === "") return true;
  const v = value;
  if (type === "texte" || type === "personne") {
    return String(v ?? "").toLowerCase().includes(String(filter.value).toLowerCase());
  }
  if (type === "nombre" || type === "financier" || type === "pourcentage") {
    const a = Number(v); const b = Number(filter.value);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return true;
    if (filter.op === ">") return a > b;
    if (filter.op === "<") return a < b;
    return a === b;
  }
  if (type === "date") {
    if (!v) return false;
    const a = new Date(v).getTime();
    if (filter.op === "before") return a < new Date(filter.value).getTime();
    if (filter.op === "after") return a > new Date(filter.value).getTime();
    if (filter.op === "between" && filter.value2) {
      const t1 = new Date(filter.value).getTime();
      const t2 = new Date(filter.value2).getTime();
      return a >= t1 && a <= t2;
    }
    return true;
  }
  if (type === "statut") {
    if (Array.isArray(filter.value)) return filter.value.length === 0 || filter.value.includes(v);
    return v === filter.value;
  }
  if (type === "case_a_cocher") {
    return Boolean(v) === Boolean(filter.value);
  }
  return true;
}

function ColumnFilterUI({ col, filter, onChange }) {
  const t = col.type;
  if (t === "statut" && col.options) {
    const sel = Array.isArray(filter?.value) ? filter.value : (filter?.value ? [filter.value] : []);
    const toggle = (opt) => {
      const next = sel.includes(opt) ? sel.filter((x) => x !== opt) : [...sel, opt];
      onChange(next.length ? { value: next } : null);
    };
    return (
      <div className="space-y-1">
        {col.options.map((opt) => (
          <button key={opt} onClick={() => toggle(opt)}
            className={`w-full text-left px-2 py-1.5 rounded-lg text-sm flex items-center gap-2 ${sel.includes(opt) ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}>
            {sel.includes(opt) && <CheckCircle2 className="w-3 h-3 shrink-0" />} {opt}
          </button>
        ))}
      </div>
    );
  }
  if (t === "case_a_cocher") {
    return (
      <div className="grid grid-cols-2 gap-1">
        <button onClick={() => onChange({ value: true })} className={`px-2 py-1.5 rounded-lg text-sm border ${filter?.value === true ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}>Oui</button>
        <button onClick={() => onChange({ value: false })} className={`px-2 py-1.5 rounded-lg text-sm border ${filter?.value === false ? "bg-slate-900 text-white" : "hover:bg-slate-50"}`}>Non</button>
      </div>
    );
  }
  if (t === "nombre" || t === "financier" || t === "pourcentage") {
    return (
      <div className="flex gap-1">
        <select className="rounded-lg border px-2 py-1.5 text-sm" value={filter?.op || "="} onChange={(e) => onChange({ ...filter, op: e.target.value, value: filter?.value ?? "" })}>
          <option value="=">=</option><option value=">">{">"}</option><option value="<">{"<"}</option>
        </select>
        <input type="number" className="flex-1 rounded-lg border px-2 py-1.5 text-sm" placeholder="valeur"
          value={filter?.value ?? ""} onChange={(e) => onChange({ op: filter?.op || "=", value: e.target.value })} />
      </div>
    );
  }
  if (t === "date") {
    return (
      <div className="space-y-1">
        <select className="w-full rounded-lg border px-2 py-1.5 text-sm" value={filter?.op || "before"} onChange={(e) => onChange({ ...filter, op: e.target.value, value: filter?.value ?? "" })}>
          <option value="before">Avant</option><option value="after">Après</option><option value="between">Entre</option>
        </select>
        <input type="date" className="w-full rounded-lg border px-2 py-1.5 text-sm" value={filter?.value ?? ""} onChange={(e) => onChange({ op: filter?.op || "before", value: e.target.value, value2: filter?.value2 })} />
        {filter?.op === "between" && (
          <input type="date" className="w-full rounded-lg border px-2 py-1.5 text-sm" value={filter?.value2 ?? ""} onChange={(e) => onChange({ ...filter, value2: e.target.value })} />
        )}
      </div>
    );
  }
  // texte / personne / fallback
  return (
    <input type="text" autoFocus className="w-full rounded-lg border px-2 py-1.5 text-sm" placeholder="contient…"
      value={filter?.value ?? ""} onChange={(e) => onChange({ value: e.target.value })} />
  );
}

function AddColumnModal({ open, onClose, onCreate, position }) {
  const [name, setName] = useState("");
  const [type, setType] = useState("texte");
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b flex items-center justify-between">
          <h3 className="font-bold">Ajouter une colonne {position === "left" ? "à gauche" : position === "right" ? "à droite" : ""}</h3>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Nom</label>
            <input autoFocus type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex : Budget"
              className="w-full rounded-xl border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Type</label>
            <div className="grid grid-cols-2 gap-2">
              {COL_TYPES.map((t) => (
                <button key={t.id} onClick={() => setType(t.id)}
                  className={`px-3 py-2 rounded-lg border text-sm text-left ${type === t.id ? "bg-slate-900 text-white border-slate-900" : "hover:bg-slate-50"}`}>
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="px-5 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-sm font-semibold hover:bg-slate-100">Annuler</button>
          <button disabled={!name.trim()} onClick={() => { onCreate({ name: name.trim(), type }); setName(""); setType("texte"); }}
            className="px-4 py-2 rounded-xl text-sm font-semibold bg-slate-900 text-white disabled:opacity-40">Créer</button>
        </div>
      </div>
    </div>
  );
}

// ===== Generic flat EntityTable (Tasks, Athletes, Clubs, Documents) =====
function EntityTable({ rows, builtinCols, config, onConfigChange, onEdit, onDelete, nameKey = "name", emptyLabel = "Aucun élément.", customFields = [] }) {
  const [openColMenu, setOpenColMenu] = useState(null);
  const [submenu, setSubmenu] = useState(null);
  const [addColModal, setAddColModal] = useState(null);

  const cfg = config || { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {}, sortCol: nameKey, sortDir: "asc" };
  const setCfg = (patch) => onConfigChange({ ...cfg, ...(typeof patch === "function" ? patch(cfg) : patch) });
  const sortCol = cfg.sortCol || nameKey;
  const sortDir = cfg.sortDir || "asc";
  const closeMenu = () => { setOpenColMenu(null); setSubmenu(null); };

  // Build cols
  const customCols = [
    ...(customFields || []).map((field) => ({ key: field.id, label: field.name, type: field.type, builtin: false, sortable: true })),
    ...(cfg.customCols || []).filter((col) => !(customFields || []).some((field) => field.id === col.key)),
  ].map((c) => ({ ...c, builtin: false, sortable: true }));
  let allCols = [...builtinCols.map((c) => ({ ...c, builtin: true })), ...customCols].map((c) => ({
    ...c,
    type: cfg.typeOverrides?.[c.key] || c.type,
    label: cfg.renamed?.[c.key] || c.label,
  }));
  if (cfg.order?.length) {
    const ordered = cfg.order.map((k) => allCols.find((c) => c.key === k)).filter(Boolean);
    const remaining = allCols.filter((c) => !cfg.order.includes(c.key));
    allCols = [...ordered, ...remaining];
  }
  const visibleCols = allCols.filter((c) => !(cfg.hiddenCols || []).includes(c.key));

  const valueFor = (row, col) => {
    if (col.builtin) {
      if (col.accessor) return col.accessor(row);
      return row[col.key];
    }
    return row.customFieldValues?.[col.key];
  };

  const filtered = rows.filter((r) => visibleCols.every((c) => passesFilter(valueFor(r, c), cfg.filters?.[c.key], c.type)));
  const sortFn = (a, b) => {
    const col = allCols.find((c) => c.key === sortCol) || allCols[0];
    const va = valueFor(a, col); const vb = valueFor(b, col);
    if (col.type === "nombre" || col.type === "financier" || col.type === "pourcentage") {
      return sortDir === "asc" ? (Number(va) || 0) - (Number(vb) || 0) : (Number(vb) || 0) - (Number(va) || 0);
    }
    const sa = String(va ?? ""); const sb = String(vb ?? "");
    return sortDir === "asc" ? sa.localeCompare(sb) : sb.localeCompare(sa);
  };
  const sorted = [...filtered].sort(sortFn);
  const activeFilters = Object.entries(cfg.filters || {}).filter(([_, v]) => v && v.value !== "" && v.value !== undefined && v.value !== null);

  // Column actions
  const setFilter = (key, val) => setCfg((c) => ({ ...c, filters: { ...(c.filters || {}), [key]: val } }));
  const clearFilter = (key) => setCfg((c) => { const f = { ...(c.filters || {}) }; delete f[key]; return { ...c, filters: f }; });
  const hideColumn = (key) => setCfg((c) => ({ ...c, hiddenCols: [...new Set([...(c.hiddenCols || []), key])] }));
  const renameColumn = (key) => {
    const cur = cfg.renamed?.[key] || allCols.find((c) => c.key === key)?.label || "";
    const next = window.prompt("Nouveau nom :", cur);
    if (next && next.trim()) setCfg((c) => ({ ...c, renamed: { ...(c.renamed || {}), [key]: next.trim() } }));
  };
  const changeType = (key, type) => setCfg((c) => {
    if (allCols.find((x) => x.key === key)?.builtin) return { ...c, typeOverrides: { ...(c.typeOverrides || {}), [key]: type } };
    return { ...c, customCols: (c.customCols || []).map((x) => x.key === key ? { ...x, type } : x) };
  });
  const duplicateColumn = (key) => setCfg((c) => {
    const src = allCols.find((x) => x.key === key);
    if (!src) return c;
    const newKey = "cf_" + uid().slice(0, 8);
    return { ...c, customCols: [...(c.customCols || []), { key: newKey, label: `Copie de ${src.label}`, type: src.type }] };
  });
  const deleteColumn = (key) => {
    if (!window.confirm("Supprimer cette colonne et toutes ses valeurs ?")) return;
    setCfg((c) => ({ ...c, customCols: (c.customCols || []).filter((x) => x.key !== key) }));
  };
  const setGroupBy = (key) => setCfg({ groupBy: cfg.groupBy === key ? null : key });
  const handleSort = (key, dir) => { setCfg({ sortCol: key, sortDir: dir }); closeMenu(); };
  const addColumn = ({ name, type }) => {
    const newKey = "cf_" + uid().slice(0, 8);
    const anchor = addColModal?.anchorKey;
    setCfg((c) => {
      const existing = [...(c.customCols || []), { key: newKey, label: name, type }];
      let order = c.order?.length ? [...c.order] : allCols.map((x) => x.key);
      if (anchor) {
        const idx = order.indexOf(anchor);
        if (addColModal.position === "left") order.splice(idx, 0, newKey);
        else order.splice(idx + 1, 0, newKey);
      } else order.push(newKey);
      return { ...c, customCols: existing, order };
    });
    setAddColModal(null);
  };

  const renderCell = (row, col) => {
    if (col.render) return col.render(row);
    const v = valueFor(row, col);
    if (col.type === "case_a_cocher") return <span>{v ? "✓" : "—"}</span>;
    if (col.type === "financier" || col.type === "nombre" || col.type === "pourcentage") return <span className="text-slate-700">{formatCustomFieldValue(col.type, v)}</span>;
    if (col.type === "statut" && v && col.options) return <Badge className={badgeClass("status", v)}>{v}</Badge>;
    return <span className="text-slate-600">{v || "—"}</span>;
  };

  const ColHeader = ({ col }) => {
    const hasFilter = cfg.filters?.[col.key] && cfg.filters[col.key].value !== undefined && cfg.filters[col.key].value !== "";
    const isOpen = openColMenu === col.key;
    return (
      <th className="py-3 px-3 text-left font-semibold text-xs text-slate-600 uppercase tracking-wide whitespace-nowrap">
        <div className="relative inline-block">
          <button onClick={(e) => { e.stopPropagation(); setOpenColMenu(isOpen ? null : col.key); setSubmenu(null); }}
            className={`flex items-center gap-1 hover:text-slate-900 ${hasFilter ? "text-blue-600" : ""}`}>
            {col.label}
            {hasFilter && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 inline-block ml-0.5" />}
            <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? "rotate-180" : ""}`} />
          </button>
          {isOpen && (
            <div className="absolute top-full left-0 z-30 mt-1 bg-white rounded-xl shadow-xl border py-1 min-w-64" onClick={(e) => e.stopPropagation()}>
              <div className="px-3 py-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5 flex items-center gap-1.5"><Filter className="w-3 h-3" /> Filtre</p>
                <ColumnFilterUI col={col} filter={cfg.filters?.[col.key]} onChange={(v) => v ? setFilter(col.key, v) : clearFilter(col.key)} />
                {hasFilter && <button onClick={() => clearFilter(col.key)} className="mt-1.5 text-xs text-red-600 hover:underline">✕ Effacer</button>}
              </div>
              <div className="border-t my-1" />
              {col.sortable !== false && (
                <>
                  <button onClick={() => handleSort(col.key, "asc")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                    <span className="text-slate-400 font-mono w-4 text-center">↑</span> Trier croissant {sortCol === col.key && sortDir === "asc" && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
                  </button>
                  <button onClick={() => handleSort(col.key, "desc")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                    <span className="text-slate-400 font-mono w-4 text-center">↓</span> Trier décroissant {sortCol === col.key && sortDir === "desc" && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
                  </button>
                  <div className="border-t my-1" />
                </>
              )}
              <button onClick={() => { setGroupBy(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-400" /> {cfg.groupBy === col.key ? "Dégrouper" : "Grouper par"}
                {cfg.groupBy === col.key && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
              </button>
              <div className="border-t my-1" />
              <button onClick={() => { duplicateColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Copy className="w-4 h-4 text-slate-400" /> Dupliquer la colonne
              </button>
              <button onClick={() => { setAddColModal({ position: "left", anchorKey: col.key }); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Plus className="w-4 h-4 text-slate-400" /> Ajouter une colonne à gauche
              </button>
              <button onClick={() => { setAddColModal({ position: "right", anchorKey: col.key }); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Plus className="w-4 h-4 text-slate-400" /> Ajouter une colonne à droite
              </button>
              <div className="relative">
                <button onClick={() => setSubmenu(submenu === "type" ? null : "type")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-slate-400 rotate-90" /> Changer le type de colonne <ChevronRight className="w-3 h-3 ml-auto" />
                </button>
                {submenu === "type" && (
                  <div className="absolute left-full top-0 ml-1 bg-white rounded-xl shadow-xl border py-1 min-w-44 z-40">
                    {COL_TYPES.map((t) => (
                      <button key={t.id} onClick={() => { changeType(col.key, t.id); closeMenu(); }}
                        className={`w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2 ${col.type === t.id ? "text-slate-900 font-semibold" : ""}`}>
                        {col.type === t.id && <CheckCircle2 className="w-3 h-3 text-green-500" />} {t.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="border-t my-1" />
              <button onClick={() => { renameColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-slate-400" /> Renommer
              </button>
              <button onClick={() => { hideColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <EyeOff className="w-4 h-4 text-slate-400" /> Masquer
              </button>
              <button onClick={() => { if (!col.builtin) { deleteColumn(col.key); closeMenu(); } }} disabled={col.builtin}
                className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 ${col.builtin ? "text-slate-300 cursor-not-allowed" : "hover:bg-red-50 text-red-600"}`}>
                <Trash2 className="w-4 h-4" /> Supprimer {col.builtin && <span className="ml-auto text-xs">(intégré)</span>}
              </button>
            </div>
          )}
        </div>
      </th>
    );
  };

  const groupCol = cfg.groupBy ? allCols.find((c) => c.key === cfg.groupBy) : null;
  const grouped = groupCol
    ? sorted.reduce((acc, r) => { const k = String(valueFor(r, groupCol) ?? "—"); (acc[k] = acc[k] || []).push(r); return acc; }, {})
    : { __all__: sorted };
  const groupKeys = Object.keys(grouped).sort();

  return (
    <>
      {(activeFilters.length > 0 || cfg.groupBy || (cfg.hiddenCols || []).length > 0) && (
        <div className="flex flex-wrap gap-2 mb-3">
          {activeFilters.map(([k, v]) => {
            const c = allCols.find((x) => x.key === k);
            const display = Array.isArray(v.value) ? v.value.join(", ") : (v.op ? `${v.op} ${v.value}` : v.value);
            return (
              <span key={k} className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full border border-blue-200">
                <Filter className="w-3 h-3" /> {c?.label || k}: <span className="font-bold">{String(display)}</span>
                <button onClick={() => clearFilter(k)} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
              </span>
            );
          })}
          {cfg.groupBy && (
            <span className="inline-flex items-center gap-1.5 bg-violet-50 text-violet-700 text-xs font-medium px-2.5 py-1 rounded-full border border-violet-200">
              <Layers className="w-3 h-3" /> Groupé par <span className="font-bold">{groupCol?.label}</span>
              <button onClick={() => setCfg({ groupBy: null })} className="hover:text-violet-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {(cfg.hiddenCols || []).length > 0 && (
            <span className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-700 text-xs font-medium px-2.5 py-1 rounded-full border">
              <EyeOff className="w-3 h-3" /> {cfg.hiddenCols.length} colonne{cfg.hiddenCols.length > 1 ? "s" : ""} masquée{cfg.hiddenCols.length > 1 ? "s" : ""}
              <button onClick={() => setCfg({ hiddenCols: [] })} className="hover:text-slate-900"><X className="w-3 h-3" /></button>
            </span>
          )}
        </div>
      )}

      <div className="bg-white rounded-2xl border overflow-x-auto shadow-sm" onClick={() => openColMenu && closeMenu()}>
        <table className="w-full text-sm min-w-[800px]">
          <thead>
            <tr className="border-b bg-slate-50">
              {visibleCols.map((col) => <ColHeader key={col.key} col={col} />)}
              <th className="py-3 px-3 w-10">
                <button onClick={(e) => { e.stopPropagation(); setAddColModal({ position: "right", anchorKey: visibleCols[visibleCols.length - 1]?.key }); }}
                  className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-500" title="Ajouter une colonne">
                  <Plus className="w-4 h-4" />
                </button>
              </th>
              <th className="w-20" />
            </tr>
          </thead>
          <tbody>
            {groupKeys.map((gk) => (
              <React.Fragment key={gk}>
                {groupCol && (
                  <tr className="bg-violet-50/50 border-b">
                    <td colSpan={visibleCols.length + 2} className="py-2 px-3 text-xs font-bold text-violet-700 uppercase tracking-wide">
                      {groupCol.label} : {gk} <span className="text-slate-400">({grouped[gk].length})</span>
                    </td>
                  </tr>
                )}
                {grouped[gk].map((row) => (
                  <tr key={row.id} className="border-b hover:bg-slate-50">
                    {visibleCols.map((col) => (
                      <td key={col.key} className="py-3 px-3">
                        {col.key === nameKey ? (
                          <p className="font-semibold text-slate-900">{row[nameKey] || row.title || "—"}</p>
                        ) : renderCell(row, col)}
                      </td>
                    ))}
                    <td />
                    <td className="py-3 px-3" onClick={(e) => e.stopPropagation()}>
                      <div className="flex gap-1.5 justify-end">
                        {onEdit && <button onClick={() => onEdit(row)} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600" title="Modifier"><Edit3 className="w-3.5 h-3.5" /></button>}
                        {onDelete && <button onClick={() => onDelete(row)} className="p-1.5 rounded-lg hover:bg-red-100 text-red-600" title="Supprimer"><Trash2 className="w-3.5 h-3.5" /></button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
        {!sorted.length && <p className="text-center text-slate-500 py-12">{emptyLabel}</p>}
      </div>

      <AddColumnModal open={!!addColModal} onClose={() => setAddColModal(null)} onCreate={addColumn} position={addColModal?.position} />
    </>
  );
}

function ProjectTable({ projects, tasks, onEdit, requestDelete, onQuickTask, config, onConfigChange, customFields = [] }) {
  const [expandedRows, setExpandedRows] = useState({});
  const [openColMenu, setOpenColMenu] = useState(null);
  const [submenu, setSubmenu] = useState(null); // 'sort' | 'type'
  const [addColModal, setAddColModal] = useState(null); // { position, anchorKey }

  const cfg = config || { customCols: [], hiddenCols: [], renamed: {}, typeOverrides: {}, order: [], groupBy: null, filters: {}, sortCol: "name", sortDir: "asc" };
  const setCfg = (patch) => onConfigChange({ ...cfg, ...(typeof patch === "function" ? patch(cfg) : patch) });
  const sortCol = cfg.sortCol || "name";
  const sortDir = cfg.sortDir || "asc";

  const toggleRow = (id) => setExpandedRows((prev) => ({ ...prev, [id]: !prev[id] }));
  const closeMenu = () => { setOpenColMenu(null); setSubmenu(null); };

  const handleSort = (key, dir) => { setCfg({ sortCol: key, sortDir: dir }); closeMenu(); };

  // ===== Column model =====
  const builtinCols = [
    { key: "name", label: "Projet", type: "texte", builtin: true, sortable: true },
    { key: "status", label: "Statut", type: "statut", builtin: true, sortable: true, options: STATUS_OPTIONS },
    { key: "priority", label: "Priorité", type: "statut", builtin: true, sortable: true, options: PRIORITY_OPTIONS },
    { key: "computedTotalProgress", label: "Avancement", type: "nombre", builtin: true, sortable: true },
    { key: "tasksCount", label: "Tâches", type: "nombre", builtin: true, sortable: false },
    { key: "owner", label: "Responsable", type: "personne", builtin: true, sortable: true },
    { key: "endDate", label: "Échéance", type: "date", builtin: true, sortable: true },
  ];
  const customCols = [
    ...(customFields || []).map((field) => ({ key: field.id, label: field.name, type: field.type, builtin: false, sortable: true })),
    ...(cfg.customCols || []).filter((col) => !(customFields || []).some((field) => field.id === col.key)),
  ].map((c) => ({ ...c, builtin: false, sortable: true }));
  // apply type overrides + renames
  let allCols = [...builtinCols, ...customCols].map((c) => ({
    ...c,
    type: cfg.typeOverrides?.[c.key] || c.type,
    label: cfg.renamed?.[c.key] || c.label,
  }));
  // apply order
  if (cfg.order?.length) {
    const ordered = cfg.order.map((k) => allCols.find((c) => c.key === k)).filter(Boolean);
    const remaining = allCols.filter((c) => !cfg.order.includes(c.key));
    allCols = [...ordered, ...remaining];
  }
  // hide
  const visibleCols = allCols.filter((c) => !(cfg.hiddenCols || []).includes(c.key));

  // ===== Filtering =====
  const valueFor = (project, col) => {
    if (col.builtin) {
      if (col.key === "tasksCount") return tasks.filter((t) => t.projectId === project.id).length;
      return project[col.key];
    }
    return project.customFieldValues?.[col.key];
  };
  const filtered = projects.filter((p) => visibleCols.every((c) => passesFilter(valueFor(p, c), cfg.filters?.[c.key], c.type)));

  // Build children index from the FULL projects list (so hierarchy is preserved)
  const childrenByParent = {};
  projects.forEach((p) => {
    const k = p.parentId || "__root__";
    (childrenByParent[k] = childrenByParent[k] || []).push(p);
  });

  const sortFn = (a, b) => {
    const col = allCols.find((c) => c.key === sortCol) || builtinCols[0];
    const va = valueFor(a, col); const vb = valueFor(b, col);
    if (col.type === "nombre" || col.type === "financier" || col.type === "pourcentage") {
      return sortDir === "asc" ? (Number(va) || 0) - (Number(vb) || 0) : (Number(vb) || 0) - (Number(va) || 0);
    }
    const sa = String(va ?? ""); const sb = String(vb ?? "");
    return sortDir === "asc" ? sa.localeCompare(sb) : sb.localeCompare(sa);
  };

  const filteredIds = new Set(filtered.map((p) => p.id));
  const roots = filtered.filter((p) => !p.parentId || !filteredIds.has(p.parentId)).sort(sortFn);
  const activeFilters = Object.entries(cfg.filters || {}).filter(([_, v]) => v && v.value !== "" && v.value !== undefined && v.value !== null);

  // ===== Cell renderer =====
  const renderCell = (project, col) => {
    const v = valueFor(project, col);
    if (col.builtin && col.key === "name") return null; // handled in special name cell
    if (col.builtin && col.key === "status") return <Badge className={badgeClass("status", project.status)}>{project.status}</Badge>;
    if (col.builtin && col.key === "priority") return <Badge className={badgeClass("priority", project.priority)}>{project.priority}</Badge>;
    if (col.builtin && col.key === "computedTotalProgress") return (
      <div className="flex items-center gap-2 min-w-32">
        <div className="flex-1 h-2 rounded-full bg-slate-200 overflow-hidden">
          <div className={`h-full rounded-full ${progressTone(project.computedTotalProgress)}`} style={{ width: `${project.computedTotalProgress}%` }} />
        </div>
        <span className="text-xs font-bold text-slate-700 w-9 text-right">{project.computedTotalProgress}%</span>
      </div>
    );
    if (col.builtin && col.key === "tasksCount") {
      const n = tasks.filter((t) => t.projectId === project.id).length;
      return <span className="text-slate-600"><span className="font-medium text-slate-800">{n}</span> tâche{n > 1 ? "s" : ""}</span>;
    }
    if (col.type === "case_a_cocher") return <span>{v ? "✓" : "—"}</span>;
    if (col.type === "financier" || col.type === "nombre" || col.type === "pourcentage") return <span className="text-slate-700">{formatCustomFieldValue(col.type, v)}</span>;
    if (col.type === "statut" && v) return <Badge className={badgeClass("status", v)}>{v}</Badge>;
    return <span className="text-slate-600">{v || "—"}</span>;
  };

  // ===== Column actions =====
  const setFilter = (key, val) => setCfg((c) => ({ ...c, filters: { ...(c.filters || {}), [key]: val } }));
  const clearFilter = (key) => setCfg((c) => { const f = { ...(c.filters || {}) }; delete f[key]; return { ...c, filters: f }; });
  const hideColumn = (key) => setCfg((c) => ({ ...c, hiddenCols: [...new Set([...(c.hiddenCols || []), key])] }));
  const renameColumn = (key) => {
    const cur = cfg.renamed?.[key] || allCols.find((c) => c.key === key)?.label || "";
    const next = window.prompt("Nouveau nom :", cur);
    if (next && next.trim()) setCfg((c) => ({ ...c, renamed: { ...(c.renamed || {}), [key]: next.trim() } }));
  };
  const changeType = (key, type) => setCfg((c) => {
    if (allCols.find((x) => x.key === key)?.builtin) return { ...c, typeOverrides: { ...(c.typeOverrides || {}), [key]: type } };
    return { ...c, customCols: (c.customCols || []).map((x) => x.key === key ? { ...x, type } : x) };
  });
  const duplicateColumn = (key) => setCfg((c) => {
    const src = allCols.find((x) => x.key === key);
    if (!src) return c;
    const newKey = "cf_" + uid().slice(0, 8);
    const newCol = { key: newKey, label: `Copie de ${src.label}`, type: src.type };
    return { ...c, customCols: [...(c.customCols || []), newCol] };
  });
  const deleteColumn = (key) => {
    if (!window.confirm("Supprimer cette colonne et toutes ses valeurs ?")) return;
    setCfg((c) => ({ ...c, customCols: (c.customCols || []).filter((x) => x.key !== key) }));
  };
  const setGroupBy = (key) => setCfg({ groupBy: cfg.groupBy === key ? null : key });
  const addColumn = ({ name, type }) => {
    const newKey = "cf_" + uid().slice(0, 8);
    const newCol = { key: newKey, label: name, type };
    const anchor = addColModal?.anchorKey;
    setCfg((c) => {
      const existing = [...(c.customCols || []), newCol];
      let order = c.order?.length ? [...c.order] : allCols.map((x) => x.key);
      if (anchor) {
        const idx = order.indexOf(anchor);
        if (addColModal.position === "left") order.splice(idx, 0, newKey);
        else order.splice(idx + 1, 0, newKey);
      } else order.push(newKey);
      return { ...c, customCols: existing, order };
    });
    setAddColModal(null);
  };

  const ColHeader = ({ col }) => {
    const hasFilter = cfg.filters?.[col.key] && cfg.filters[col.key].value !== undefined && cfg.filters[col.key].value !== "";
    const isOpen = openColMenu === col.key;
    return (
      <th className="py-3 px-3 text-left font-semibold text-xs text-slate-600 uppercase tracking-wide whitespace-nowrap">
        <div className="relative inline-block">
          <button onClick={(e) => { e.stopPropagation(); setOpenColMenu(isOpen ? null : col.key); setSubmenu(null); }}
            className={`flex items-center gap-1 hover:text-slate-900 ${hasFilter ? "text-blue-600" : ""}`}>
            {col.label}
            {hasFilter && <span className="w-1.5 h-1.5 rounded-full bg-blue-500 inline-block ml-0.5" />}
            <ChevronDown className={`w-3 h-3 transition-transform ${isOpen ? "rotate-180" : ""}`} />
          </button>
          {isOpen && (
            <div className="absolute top-full left-0 z-30 mt-1 bg-white rounded-xl shadow-xl border py-1 min-w-64" onClick={(e) => e.stopPropagation()}>
              {/* Filtre */}
              <div className="px-3 py-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5 flex items-center gap-1.5"><Filter className="w-3 h-3" /> Filtre</p>
                <ColumnFilterUI col={col} filter={cfg.filters?.[col.key]} onChange={(v) => v ? setFilter(col.key, v) : clearFilter(col.key)} />
                {hasFilter && (
                  <button onClick={() => { clearFilter(col.key); }} className="mt-1.5 text-xs text-red-600 hover:underline">✕ Effacer</button>
                )}
              </div>
              <div className="border-t my-1" />
              {/* Trier */}
              {col.sortable && (
                <>
                  <button onClick={() => handleSort(col.key, "asc")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                    <span className="text-slate-400 font-mono w-4 text-center">↑</span> Trier croissant {sortCol === col.key && sortDir === "asc" && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
                  </button>
                  <button onClick={() => handleSort(col.key, "desc")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                    <span className="text-slate-400 font-mono w-4 text-center">↓</span> Trier décroissant {sortCol === col.key && sortDir === "desc" && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
                  </button>
                  <div className="border-t my-1" />
                </>
              )}
              {/* Grouper par */}
              <button onClick={() => { setGroupBy(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-400" /> {cfg.groupBy === col.key ? "Dégrouper" : "Grouper par"}
                {cfg.groupBy === col.key && <CheckCircle2 className="w-3 h-3 text-green-500 ml-auto" />}
              </button>
              <div className="border-t my-1" />
              {/* Dupliquer */}
              <button onClick={() => { duplicateColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Copy className="w-4 h-4 text-slate-400" /> Dupliquer la colonne
              </button>
              <button onClick={() => { setAddColModal({ position: "left", anchorKey: col.key }); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Plus className="w-4 h-4 text-slate-400" /> Ajouter une colonne à gauche
              </button>
              <button onClick={() => { setAddColModal({ position: "right", anchorKey: col.key }); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Plus className="w-4 h-4 text-slate-400" /> Ajouter une colonne à droite
              </button>
              {/* Changer le type */}
              <div className="relative">
                <button onClick={() => setSubmenu(submenu === "type" ? null : "type")} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-slate-400 rotate-90" /> Changer le type de colonne <ChevronRight className="w-3 h-3 ml-auto" />
                </button>
                {submenu === "type" && (
                  <div className="absolute left-full top-0 ml-1 bg-white rounded-xl shadow-xl border py-1 min-w-44 z-40">
                    {COL_TYPES.map((t) => (
                      <button key={t.id} onClick={() => { changeType(col.key, t.id); closeMenu(); }}
                        className={`w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2 ${col.type === t.id ? "text-slate-900 font-semibold" : ""}`}>
                        {col.type === t.id && <CheckCircle2 className="w-3 h-3 text-green-500" />} {t.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="border-t my-1" />
              <button onClick={() => { renameColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-slate-400" /> Renommer
              </button>
              <button onClick={() => { hideColumn(col.key); closeMenu(); }} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 flex items-center gap-2">
                <EyeOff className="w-4 h-4 text-slate-400" /> Masquer
              </button>
              <button onClick={() => { if (!col.builtin) { deleteColumn(col.key); closeMenu(); } }} disabled={col.builtin}
                className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 ${col.builtin ? "text-slate-300 cursor-not-allowed" : "hover:bg-red-50 text-red-600"}`}>
                <Trash2 className="w-4 h-4" /> Supprimer {col.builtin && <span className="ml-auto text-xs">(intégré)</span>}
              </button>
            </div>
          )}
        </div>
      </th>
    );
  };

  // ===== Render rows =====
  const nameCol = visibleCols.find((c) => c.key === "name");
  const otherCols = visibleCols.filter((c) => c.key !== "name");

  const renderProjectRow = (project, depth) => {
    const projectTasks = tasks.filter((t) => t.projectId === project.id);
    const childProjects = (childrenByParent[project.id] || []).filter((c) => filteredIds.has(c.id)).sort(sortFn);
    const hasChildren = childProjects.length > 0 || projectTasks.length > 0;
    const isOpen = expandedRows[project.id];
    const indentPx = depth * 24;
    const rows = [];

    rows.push(
      <tr key={project.id} className={`border-b hover:bg-slate-50 ${depth > 0 ? "bg-slate-50/30" : ""}`}>
        <td className="py-3 px-3 text-slate-400 cursor-pointer" onClick={() => hasChildren && toggleRow(project.id)}>
          {hasChildren ? (isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />) : <div className="w-4" />}
        </td>
        {nameCol && (
          <td className="py-3 px-3 cursor-pointer" onClick={() => hasChildren && toggleRow(project.id)}>
            <div style={{ paddingLeft: indentPx }}>
              <div className="flex items-center gap-2">
                {depth > 0 && <span className="text-slate-300 text-xs">↳</span>}
                <p className="font-semibold text-slate-900">{project.name}</p>
                {childProjects.length > 0 && <span className="text-xs text-slate-400">({childProjects.length} sous-projet{childProjects.length > 1 ? "s" : ""})</span>}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{project.sportName}</p>
            </div>
          </td>
        )}
        {otherCols.map((col) => <td key={col.key} className="py-3 px-3">{renderCell(project, col)}</td>)}
        {/* spacer for + col */}
        <td />
        {/* Actions */}
        <td className="py-3 px-3 sticky right-0 bg-white" onClick={(e) => e.stopPropagation()}>
          <div className="flex gap-1.5 justify-end">
            <button onClick={() => onEdit(project)} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600" title="Modifier"><Edit3 className="w-3.5 h-3.5" /></button>
            <button onClick={() => onQuickTask(project.id)} className="p-1.5 rounded-lg hover:bg-blue-100 text-blue-700" title="Ajouter tâche"><Plus className="w-3.5 h-3.5" /></button>
            <button onClick={() => requestDelete("project", project)} className="p-1.5 rounded-lg hover:bg-red-100 text-red-600" title="Supprimer"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        </td>
      </tr>
    );

    if (isOpen) {
      childProjects.forEach((child) => rows.push(...renderProjectRow(child, depth + 1)));
      projectTasks.forEach((task) => {
        const prog = normalizeTaskProgress(task.progress, task.status);
        rows.push(
          <tr key={task.id} className="border-b bg-slate-50/60 text-sm">
            <td />
            {nameCol && (
              <td className="py-2.5 px-3">
                <div style={{ paddingLeft: indentPx + 24 }}>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${task.status === "Terminé" ? "text-green-500" : "text-slate-300"}`} />
                    <span className="text-slate-800 font-medium">{task.title}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 pl-5">{task.assignee || "Non assigné"} · {task.endDate || "Sans échéance"}</p>
                </div>
              </td>
            )}
            {otherCols.map((col) => {
              if (col.key === "status") return <td key={col.key} className="py-2.5 px-3"><Badge className={`${badgeClass("status", task.status)} !text-xs`}>{task.status}</Badge></td>;
              if (col.key === "priority") return <td key={col.key} className="py-2.5 px-3"><Badge className={`${badgeClass("priority", task.priority)} !text-xs`}>{task.priority}</Badge></td>;
              if (col.key === "computedTotalProgress") return (
                <td key={col.key} className="py-2.5 px-3 min-w-32">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 rounded-full bg-slate-200 overflow-hidden">
                      <div className={`h-full rounded-full ${progressTone(prog)}`} style={{ width: `${prog}%` }} />
                    </div>
                    <span className="text-xs font-bold text-slate-600 w-8 text-right">{prog}%</span>
                  </div>
                </td>
              );
              return <td key={col.key} />;
            })}
            <td /><td />
          </tr>
        );
      });
    }
    return rows;
  };

  // ===== Grouping =====
  const groupCol = cfg.groupBy ? allCols.find((c) => c.key === cfg.groupBy) : null;
  const groupedRoots = groupCol
    ? roots.reduce((acc, p) => { const k = String(valueFor(p, groupCol) ?? "—"); (acc[k] = acc[k] || []).push(p); return acc; }, {})
    : { __all__: roots };
  const groupKeys = Object.keys(groupedRoots).sort();

  return (
    <>
      {/* Active filter chips */}
      {(activeFilters.length > 0 || cfg.groupBy) && (
        <div className="flex flex-wrap gap-2 mb-3">
          {activeFilters.map(([k, v]) => {
            const c = allCols.find((x) => x.key === k);
            const display = Array.isArray(v.value) ? v.value.join(", ") : (v.op ? `${v.op} ${v.value}` : v.value);
            return (
              <span key={k} className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-700 text-xs font-medium px-2.5 py-1 rounded-full border border-blue-200">
                <Filter className="w-3 h-3" /> {c?.label || k}: <span className="font-bold">{String(display)}</span>
                <button onClick={() => clearFilter(k)} className="hover:text-blue-900"><X className="w-3 h-3" /></button>
              </span>
            );
          })}
          {cfg.groupBy && (
            <span className="inline-flex items-center gap-1.5 bg-violet-50 text-violet-700 text-xs font-medium px-2.5 py-1 rounded-full border border-violet-200">
              <Layers className="w-3 h-3" /> Groupé par <span className="font-bold">{groupCol?.label}</span>
              <button onClick={() => setCfg({ groupBy: null })} className="hover:text-violet-900"><X className="w-3 h-3" /></button>
            </span>
          )}
          {(cfg.hiddenCols || []).length > 0 && (
            <span className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-700 text-xs font-medium px-2.5 py-1 rounded-full border">
              <EyeOff className="w-3 h-3" /> {cfg.hiddenCols.length} colonne{cfg.hiddenCols.length > 1 ? "s" : ""} masquée{cfg.hiddenCols.length > 1 ? "s" : ""}
              <button onClick={() => setCfg({ hiddenCols: [] })} className="hover:text-slate-900"><X className="w-3 h-3" /></button>
            </span>
          )}
        </div>
      )}

      <div className="bg-white rounded-2xl border overflow-x-auto shadow-sm" onClick={() => openColMenu && closeMenu()}>
        <table className="w-full text-sm min-w-[900px]">
          <thead>
            <tr className="border-b bg-slate-50">
              <th className="w-8 py-3 px-3" />
              {visibleCols.map((col) => <ColHeader key={col.key} col={col} />)}
              <th className="py-3 px-3 w-10">
                <button onClick={(e) => { e.stopPropagation(); setAddColModal({ position: "right", anchorKey: visibleCols[visibleCols.length - 1]?.key }); }}
                  className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-500" title="Ajouter une colonne">
                  <Plus className="w-4 h-4" />
                </button>
              </th>
              <th className="w-24" />
            </tr>
          </thead>
          <tbody>
            {groupKeys.map((gk) => (
              <React.Fragment key={gk}>
                {groupCol && (
                  <tr className="bg-violet-50/50 border-b">
                    <td colSpan={visibleCols.length + 3} className="py-2 px-3 text-xs font-bold text-violet-700 uppercase tracking-wide">
                      {groupCol.label} : {gk}  <span className="text-slate-400">({groupedRoots[gk].length})</span>
                    </td>
                  </tr>
                )}
                {groupedRoots[gk].flatMap((p) => renderProjectRow(p, 0))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
        {!roots.length && <p className="text-center text-slate-500 py-12">Aucun projet trouvé.</p>}
      </div>

      <AddColumnModal open={!!addColModal} onClose={() => setAddColModal(null)} onCreate={addColumn} position={addColModal?.position} />
    </>
  );
}

function GuidedInputPanel({ open, onClose, allSports, projects, onSave }) {
  const [type, setType] = useState(null);
  const [form, setForm] = useState({});

  const ff = (key, val) => setForm((prev) => ({ ...prev, [key]: val }));
  const close = () => { setType(null); setForm({}); onClose(); };

  const types = [
    { id: "project", label: "Projet", Icon: FolderKanban, color: "bg-violet-100 text-violet-700" },
    { id: "task", label: "Tâche", Icon: ListChecks, color: "bg-blue-100 text-blue-700" },
    { id: "athlete", label: "Athlète", Icon: Users, color: "bg-green-100 text-green-700" },
    { id: "club", label: "Club", Icon: Building2, color: "bg-amber-100 text-amber-700" },
  ];

  const handleSave = () => {
    if (!type || !(form.name || form.title)) return;
    onSave(type, { status: "À faire", priority: "Moyenne", sport: allSports[0]?.id || "developpe_couche", customFieldValues: {}, ...form });
    close();
  };

  if (!open) return null;

  const inp = "w-full rounded-2xl border px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900";

  const Field = ({ label, children }) => (
    <div>
      <label className="block text-sm font-bold text-slate-800 mb-2">{label}</label>
      {children}
    </div>
  );

  const StatusToggle = ({ options, value, onChange }) => (
    <div className="grid grid-cols-2 gap-2">
      {options.map((s) => (
        <button key={s} type="button" onClick={() => onChange(s)}
          className={`py-2.5 rounded-xl border text-sm font-medium transition-colors ${value === s ? "bg-slate-900 text-white border-slate-900" : "hover:bg-slate-50"}`}>
          {s}
        </button>
      ))}
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/30" onClick={close} />
      <div className="w-[480px] bg-white h-full shadow-2xl flex flex-col">
        <div className="px-6 py-5 border-b flex items-center justify-between shrink-0">
          <h2 className="font-bold text-lg text-slate-900">Saisie guidée</h2>
          <button onClick={close} className="text-slate-400 hover:text-slate-700"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex-1 overflow-auto p-6 space-y-7">
          {/* Type selector */}
          <Field label="Type d'élément">
            <div className="grid grid-cols-2 gap-2">
              {types.map((t) => (
                <button key={t.id} type="button"
                  onClick={() => { setType(t.id); setForm({ status: "À faire", priority: "Moyenne", sport: allSports[0]?.id || "developpe_couche", customFieldValues: {} }); }}
                  className={`flex items-center gap-3 p-3 rounded-2xl border-2 text-left transition-all ${type === t.id ? "border-slate-900 bg-slate-50" : "border-slate-200 hover:border-slate-400"}`}>
                  <div className={`w-8 h-8 rounded-xl ${t.color} flex items-center justify-center shrink-0`}>
                    <t.Icon className="w-4 h-4" />
                  </div>
                  <span className="font-semibold text-sm text-slate-900">{t.label}</span>
                </button>
              ))}
            </div>
          </Field>

          {type === "project" && <>
            <Field label="Nom du projet *">
              <input autoFocus className={inp} placeholder="ex : Challenge régional 2026" value={form.name || ""} onChange={(e) => ff("name", e.target.value)} />
            </Field>
            <Field label="Description">
              <textarea className={`${inp} resize-none h-24`} placeholder="Objectif, contexte…" value={form.description || ""} onChange={(e) => ff("description", e.target.value)} />
            </Field>
            <Field label="Sport">
              <select className={inp} value={form.sport || ""} onChange={(e) => ff("sport", e.target.value)}>
                {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </Field>
            <Field label="Priorité">
              <StatusToggle options={PRIORITY_OPTIONS} value={form.priority} onChange={(v) => ff("priority", v)} />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Date de début"><input type="date" className={inp} value={form.startDate || ""} onChange={(e) => ff("startDate", e.target.value)} /></Field>
              <Field label="Date de fin"><input type="date" className={inp} value={form.endDate || ""} onChange={(e) => ff("endDate", e.target.value)} /></Field>
            </div>
            <Field label="Responsable">
              <input className={inp} placeholder="Nom du responsable" value={form.owner || ""} onChange={(e) => ff("owner", e.target.value)} />
            </Field>
            <Field label="Projet parent (optionnel)">
              <select className={inp} value={form.parentId || ""} onChange={(e) => ff("parentId", e.target.value || null)}>
                <option value="">Aucun (projet racine)</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
          </>}

          {type === "task" && <>
            <Field label="Titre de la tâche *">
              <input autoFocus className={inp} placeholder="ex : Envoyer les convocations" value={form.title || ""} onChange={(e) => ff("title", e.target.value)} />
            </Field>
            <Field label="Projet associé">
              <select className={inp} value={form.projectId || ""} onChange={(e) => ff("projectId", e.target.value)}>
                <option value="">Aucun projet</option>
                {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </Field>
            <Field label="Assigné à">
              <input className={inp} placeholder="Nom" value={form.assignee || ""} onChange={(e) => ff("assignee", e.target.value)} />
            </Field>
            <Field label="Priorité">
              <StatusToggle options={PRIORITY_OPTIONS} value={form.priority} onChange={(v) => ff("priority", v)} />
            </Field>
            <Field label="Statut">
              <StatusToggle options={STATUS_OPTIONS} value={form.status} onChange={(v) => ff("status", v)} />
            </Field>
            <Field label="Échéance">
              <input type="date" className={inp} value={form.endDate || ""} onChange={(e) => ff("endDate", e.target.value)} />
            </Field>
          </>}

          {type === "athlete" && <>
            <Field label="Nom complet *">
              <input autoFocus className={inp} placeholder="Prénom Nom" value={form.name || ""} onChange={(e) => ff("name", e.target.value)} />
            </Field>
            <Field label="Sport">
              <select className={inp} value={form.sport || ""} onChange={(e) => ff("sport", e.target.value)}>
                {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </Field>
            <Field label="Catégorie">
              <input className={inp} placeholder="-88 kg, U13…" value={form.category || ""} onChange={(e) => ff("category", e.target.value)} />
            </Field>
            <Field label="Statut">
              <StatusToggle options={ATHLETE_STATUS} value={form.status} onChange={(v) => ff("status", v)} />
            </Field>
            <Field label="Coach">
              <input className={inp} placeholder="Nom du coach" value={form.coach || ""} onChange={(e) => ff("coach", e.target.value)} />
            </Field>
            <Field label="Email">
              <input type="email" className={inp} value={form.email || ""} onChange={(e) => ff("email", e.target.value)} />
            </Field>
          </>}

          {type === "club" && <>
            <Field label="Nom du club *">
              <input autoFocus className={inp} placeholder="ex : Club Athlétisme Paris" value={form.name || ""} onChange={(e) => ff("name", e.target.value)} />
            </Field>
            <Field label="Sport">
              <select className={inp} value={form.sport || ""} onChange={(e) => ff("sport", e.target.value)}>
                {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </Field>
            <Field label="Ville">
              <input className={inp} placeholder="Ville" value={form.city || ""} onChange={(e) => ff("city", e.target.value)} />
            </Field>
            <Field label="Statut">
              <StatusToggle options={CLUB_STATUS} value={form.status} onChange={(v) => ff("status", v)} />
            </Field>
            <Field label="Contact">
              <input className={inp} placeholder="Nom du responsable" value={form.contactName || ""} onChange={(e) => ff("contactName", e.target.value)} />
            </Field>
            <Field label="Email">
              <input type="email" className={inp} value={form.email || ""} onChange={(e) => ff("email", e.target.value)} />
            </Field>
          </>}
        </div>

        <div className="px-6 py-4 border-t shrink-0">
          <button
            type="button"
            onClick={handleSave}
            disabled={!type || !(form.name || form.title)}
            className="w-full py-4 rounded-2xl bg-slate-900 text-white text-base font-bold disabled:opacity-40 hover:bg-slate-800 transition-colors"
          >
            Créer
          </button>
        </div>
      </div>
    </div>
  );
}

function WorkspaceSelector({ workspaces, currentWorkspaceId, onChange, onNew }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = workspaces.find((w) => w.id === currentWorkspaceId) || workspaces[0];

  useEffect(() => {
    if (!open) return;
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);

  return (
    <div className="relative px-3 py-3 border-b border-slate-200" ref={ref}>
      <button onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2.5 px-2 py-2 rounded-2xl hover:bg-slate-50 transition-colors">
        <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0"
          style={{ backgroundColor: current?.color || "#0f172a" }}>
          {current?.initial || "J"}
        </div>
        <span className="text-sm font-semibold text-slate-900 flex-1 text-left truncate">{current?.name || "JAM"}</span>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="absolute top-full left-3 right-3 z-50 bg-white rounded-2xl shadow-xl border mt-1 py-1">
          {workspaces.map((ws) => (
            <button key={ws.id} onClick={() => { onChange(ws.id); setOpen(false); }}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-left transition-colors ${ws.id === currentWorkspaceId ? "bg-slate-50" : "hover:bg-slate-50"}`}>
              <div className="w-6 h-6 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0"
                style={{ backgroundColor: ws.color || "#0f172a" }}>
                {ws.initial}
              </div>
              <span className="text-sm font-medium flex-1">{ws.name}</span>
              {ws.id === currentWorkspaceId && <CheckCircle2 className="w-4 h-4 text-green-500" />}
            </button>
          ))}
          <div className="border-t my-1" />
          <button onClick={() => { onNew(); setOpen(false); }}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left hover:bg-slate-50 text-slate-600">
            <div className="w-6 h-6 rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center shrink-0">
              <Plus className="w-3 h-3 text-slate-400" />
            </div>
            <span className="text-sm">Nouvel espace de travail</span>
          </button>
        </div>
      )}
    </div>
  );
}

export default function JamSaaSApp() {
  const [data, setData] = useState(loadData);
  const [view, setView] = useState("dashboard");
  const [expanded, setExpanded] = useState({});

  // Filters
  const [searchQ, setSearchQ] = useState("");
  const [filterSport, setFilterSport] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [docMode, setDocMode] = useState("all");

  // Modals
  const [projectModal, setProjectModal] = useState({ open: false, item: null });
  const [taskModal, setTaskModal] = useState({ open: false, item: null });
  const [athleteModal, setAthleteModal] = useState({ open: false, item: null });
  const [clubModal, setClubModal] = useState({ open: false, item: null });
  const [docModal, setDocModal] = useState({ open: false, item: null });
  const [convModal, setConvModal] = useState({ open: false, item: null });
  const [notifModal, setNotifModal] = useState({ open: false, item: null });
  const [cfModal, setCfModal] = useState({ open: false, item: null });
  const [deleteConfirm, setDeleteConfirm] = useState({ open: false, type: null, item: null });
  const [projectViewMode, setProjectViewMode] = useState("tree");
  const [taskViewMode, setTaskViewMode] = useState("table");
  const [athleteViewMode, setAthleteViewMode] = useState("table");
  const [clubViewMode, setClubViewMode] = useState("table");
  const [documentViewMode, setDocumentViewMode] = useState("table");
  const [convocationViewMode, setConvocationViewMode] = useState("kanban");
  const [notificationViewMode, setNotificationViewMode] = useState("kanban");
  const [guidedOpen, setGuidedOpen] = useState(false);
  const [wsModal, setWsModal] = useState(false);
  const [wsForm, setWsForm] = useState({});

  // Form state
  const [form, setForm] = useState({});
  const [newSportName, setNewSportName] = useState("");

  const allSports = useMemo(() => [...BASE_SPORTS, ...data.customSports], [data.customSports]);
  const sportName = (id) => allSports.find((s) => s.id === id)?.name || id;

  useEffect(() => { saveData(data); }, [data]);

  const upd = (key, fn) => setData((prev) => ({ ...prev, [key]: fn(prev[key]) }));

  const legacyProjectCustomFields = useMemo(() => data.customFields.filter((field) => field.appliesTo.includes("projects")), [data.customFields]);
  const legacyTaskCustomFields = useMemo(() => data.customFields.filter((field) => field.appliesTo.includes("tasks")), [data.customFields]);
  const tableProjectCustomFields = useMemo(
    () => tableColumnsToFields(data.tableConfig?.projects?.customCols, ["projects"]),
    [data.tableConfig?.projects?.customCols]
  );
  const tableTaskCustomFields = useMemo(
    () => tableColumnsToFields(data.tableConfig?.tasks?.customCols, ["tasks"]),
    [data.tableConfig?.tasks?.customCols]
  );
  const projectCustomFields = useMemo(
    () => mergeCustomFields(legacyProjectCustomFields, tableProjectCustomFields),
    [legacyProjectCustomFields, tableProjectCustomFields]
  );
  const taskCustomFields = useMemo(
    () => mergeCustomFields(legacyTaskCustomFields, tableTaskCustomFields),
    [legacyTaskCustomFields, tableTaskCustomFields]
  );

  // Form helpers
  const f = (key, val) => setForm((prev) => ({ ...prev, [key]: val }));
  const fcf = (id, val) => setForm((prev) => ({ ...prev, customFieldValues: { ...prev.customFieldValues, [id]: val } }));

  const resetFilters = () => {
    setSearchQ(""); setFilterSport("all"); setFilterStatus("all");
    setFilterPriority("all"); setDocMode("all");
  };

  // Handlers
  const handleQuickTask = (projectId) => {
    setForm({ projectId, title: "", assignee: "", status: "À faire", priority: "Moyenne", progress: 0, startDate: "", endDate: "", description: "", customFieldValues: {} });
    setTaskModal({ open: true, item: null });
  };

  const handleEditProject = (item) => {
    setForm({ ...item });
    setProjectModal({ open: true, item });
  };

  const requestDelete = (type, item) => setDeleteConfirm({ open: true, type, item });

  const confirmDelete = () => {
    const { type, item } = deleteConfirm;
    const map = { project: "projects", task: "tasks", athlete: "athletes", club: "clubs", document: "documents", convocation: "convocations", notification: "notifications", customField: "customFields" };
    if (map[type]) upd(map[type], (arr) => arr.filter((x) => x.id !== item.id));
    setDeleteConfirm({ open: false, type: null, item: null });
  };

  const saveProject = () => {
    const item = { workspaceId: currentWsId, ...form, id: form.id || uid(), durationDays: daysBetween(form.startDate, form.endDate), customFieldValues: form.customFieldValues || {} };
    upd("projects", (arr) => form.id ? arr.map((p) => p.id === form.id ? item : p) : [...arr, item]);
    setProjectModal({ open: false, item: null }); setForm({});
  };

  const saveTask = () => {
    const progress = normalizeTaskProgress(form.progress, form.status);
    const status = form.status === "Terminé" ? "Terminé" : statusFromProgress(progress, form.status);
    const item = { workspaceId: currentWsId, ...form, id: form.id || uid(), progress, status, durationDays: daysBetween(form.startDate, form.endDate), customFieldValues: form.customFieldValues || {} };
    upd("tasks", (arr) => form.id ? arr.map((t) => t.id === form.id ? item : t) : [...arr, item]);
    setTaskModal({ open: false, item: null }); setForm({});
  };

  const saveAthlete = () => {
    const item = { workspaceId: currentWsId, ...form, id: form.id || uid() };
    upd("athletes", (arr) => form.id ? arr.map((a) => a.id === form.id ? item : a) : [...arr, item]);
    setAthleteModal({ open: false, item: null }); setForm({});
  };

  const saveClub = () => {
    const item = { workspaceId: currentWsId, ...form, id: form.id || uid() };
    upd("clubs", (arr) => form.id ? arr.map((c) => c.id === form.id ? item : c) : [...arr, item]);
    setClubModal({ open: false, item: null }); setForm({});
  };

  const saveDoc = () => {
    const item = { ...form, id: form.id || uid() };
    upd("documents", (arr) => form.id ? arr.map((d) => d.id === form.id ? item : d) : [...arr, item]);
    setDocModal({ open: false, item: null }); setForm({});
  };

  const saveConv = () => {
    const item = { ...form, id: form.id || uid() };
    upd("convocations", (arr) => form.id ? arr.map((c) => c.id === form.id ? item : c) : [...arr, item]);
    setConvModal({ open: false, item: null }); setForm({});
  };

  const saveNotif = () => {
    const item = { ...form, id: form.id || uid() };
    upd("notifications", (arr) => form.id ? arr.map((n) => n.id === form.id ? item : n) : [...arr, item]);
    setNotifModal({ open: false, item: null }); setForm({});
  };

  const saveCF = () => {
    const item = { ...form, id: form.id || uid(), appliesTo: form.appliesTo || ["projects"] };
    upd("customFields", (arr) => form.id ? arr.map((x) => x.id === form.id ? item : x) : [...arr, item]);
    setCfModal({ open: false, item: null }); setForm({});
  };

  const addSport = () => {
    if (!newSportName.trim()) return;
    const id = makeSportId(newSportName);
    if (allSports.find((s) => s.id === id)) return;
    upd("customSports", (arr) => [...arr, { id, name: newSportName.trim(), icon: Trophy }]);
    setNewSportName("");
  };

  const currentWsId = data.currentWorkspaceId || "ws_jam";
  const switchWorkspace = (wsId) => setData((prev) => ({ ...prev, currentWorkspaceId: wsId }));
  const saveWorkspace = () => {
    if (!wsForm.name?.trim()) return;
    const ws = { id: uid(), name: wsForm.name.trim(), color: wsForm.color || "#0f172a", initial: (wsForm.name.trim()[0] || "W").toUpperCase() };
    setData((prev) => ({ ...prev, workspaces: [...(prev.workspaces || []), ws], currentWorkspaceId: ws.id }));
    setWsModal(false); setWsForm({});
  };

  const handleDuplicate = (project) => {
    const newId = uid();
    const clone = { ...project, id: newId, name: `${project.name} (copie)`, parentId: project.parentId, workspaceId: currentWsId };
    upd("projects", (arr) => [...arr, clone]);
  };

  const handleGuidedSave = (type, guidedForm) => {
    if (type === "project") {
      const item = { workspaceId: currentWsId, ...guidedForm, id: uid(), durationDays: daysBetween(guidedForm.startDate, guidedForm.endDate), customFieldValues: {} };
      upd("projects", (arr) => [...arr, item]);
    }
    if (type === "task") {
      const progress = normalizeTaskProgress(0, guidedForm.status || "À faire");
      const item = { workspaceId: currentWsId, ...guidedForm, id: uid(), progress, durationDays: daysBetween(guidedForm.startDate, guidedForm.endDate), customFieldValues: {} };
      upd("tasks", (arr) => [...arr, item]);
    }
    if (type === "athlete") upd("athletes", (arr) => [...arr, { workspaceId: currentWsId, ...guidedForm, id: uid() }]);
    if (type === "club") upd("clubs", (arr) => [...arr, { workspaceId: currentWsId, ...guidedForm, id: uid() }]);
  };

  const updateProjectStatus = (id, status) => {
    upd("projects", (arr) => arr.map((project) => project.id === id ? { ...project, status } : project));
  };

  const updateTaskStatus = (id, status) => {
    upd("tasks", (arr) => arr.map((task) => {
      if (task.id !== id) return task;
      const progress = normalizeTaskProgress(task.progress, status);
      return { ...task, status: statusFromProgress(progress, status), progress };
    }));
  };

  const updateEntityStatus = (key, id, status) => {
    upd(key, (arr) => arr.map((item) => item.id === id ? { ...item, status } : item));
  };

  // Enriched + filtered data (workspace-scoped)
  const wsProjects = useMemo(() => data.projects.filter((p) => p.workspaceId === currentWsId), [data.projects, currentWsId]);
  const wsTasks = useMemo(() => data.tasks.filter((t) => t.workspaceId === currentWsId), [data.tasks, currentWsId]);
  const wsAthletes = useMemo(() => data.athletes.filter((a) => a.workspaceId === currentWsId), [data.athletes, currentWsId]);
  const wsClubs = useMemo(() => data.clubs.filter((c) => c.workspaceId === currentWsId), [data.clubs, currentWsId]);

  const enrichedProjects = useMemo(() =>
    wsProjects.map((p) => {
      const projectScope = descendants(p.id, wsProjects);
      const hasLinkedTasks = wsTasks.some((task) => projectScope.has(task.projectId));
      const computedOwnProgress = ownProgress(p.id, wsTasks);
      const computedTotalProgress = consolidatedProgress(p.id, wsTasks, wsProjects);
      return {
        ...p,
        status: hasLinkedTasks ? deriveProjectStatus(computedTotalProgress, p.status) : p.status,
        sportName: sportName(p.sport),
        computedOwnProgress,
        computedTotalProgress,
      };
    }), [wsProjects, wsTasks, allSports]);

  const filteredProjects = useMemo(() => enrichedProjects.filter((p) => {
    if (filterSport !== "all" && p.sport !== filterSport) return false;
    if (filterStatus !== "all" && p.status !== filterStatus) return false;
    if (searchQ && !p.name.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [enrichedProjects, filterSport, filterStatus, searchQ]);

  const filteredTasks = useMemo(() => wsTasks.filter((t) => {
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    if (filterPriority !== "all" && t.priority !== filterPriority) return false;
    if (searchQ && !t.title.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsTasks, filterStatus, filterPriority, searchQ]);

  const filteredAthletes = useMemo(() => wsAthletes.filter((a) => {
    if (filterSport !== "all" && a.sport !== filterSport) return false;
    if (filterStatus !== "all" && a.status !== filterStatus) return false;
    if (searchQ && !a.name.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsAthletes, filterSport, filterStatus, searchQ]);

  const filteredClubs = useMemo(() => wsClubs.filter((c) => {
    if (filterSport !== "all" && c.sport !== filterSport) return false;
    if (filterStatus !== "all" && c.status !== filterStatus) return false;
    if (searchQ && !c.name.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsClubs, filterSport, filterStatus, searchQ]);

  const wsDocs = useMemo(() => data.documents.filter((d) => d.workspaceId === currentWsId), [data.documents, currentWsId]);
  const wsConvocations = useMemo(() => data.convocations.filter((c) => c.workspaceId === currentWsId), [data.convocations, currentWsId]);
  const wsNotifications = useMemo(() => data.notifications.filter((n) => n.workspaceId === currentWsId), [data.notifications, currentWsId]);

  const filteredDocs = useMemo(() => wsDocs.filter((d) => {
    if (filterSport !== "all" && d.sport !== filterSport) return false;
    if (filterStatus !== "all" && d.status !== filterStatus) return false;
    if (docMode === "internal" && d.url) return false;
    if (docMode === "external" && !d.url) return false;
    if (searchQ && !d.title.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsDocs, filterSport, filterStatus, docMode, searchQ]);

  const filteredConvocations = useMemo(() => wsConvocations.filter((conv) => {
    if (filterSport !== "all" && conv.sport !== filterSport) return false;
    if (filterStatus !== "all" && conv.status !== filterStatus) return false;
    if (searchQ && !conv.title.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsConvocations, filterSport, filterStatus, searchQ]);

  const filteredNotifications = useMemo(() => wsNotifications.filter((notif) => {
    if (filterSport !== "all" && notif.sport !== filterSport) return false;
    if (filterStatus !== "all" && notif.status !== filterStatus) return false;
    if (searchQ && !notif.title.toLowerCase().includes(searchQ.toLowerCase())) return false;
    return true;
  }), [wsNotifications, filterSport, filterStatus, searchQ]);

  const projectTree = useMemo(() => buildTree(filteredProjects), [filteredProjects]);

  // Dashboard stats (workspace-scoped)
  const totalTasks = wsTasks.length;
  const completedTasks = wsTasks.filter((t) => t.status === "Terminé").length;
  const inProgressTasks = wsTasks.filter((t) => t.status === "En cours").length;
  const avgProgress = totalTasks ? Math.round(wsTasks.reduce((s, t) => s + normalizeTaskProgress(t.progress, t.status), 0) / totalTasks) : 0;

  const navItems = [
    { id: "dashboard", label: "Tableau de bord", Icon: LayoutDashboard },
    { id: "projects", label: "Projets", Icon: FolderKanban },
    { id: "tasks", label: "Tâches", Icon: ListChecks },
    { id: "athletes", label: "Athlètes", Icon: Users },
    { id: "clubs", label: "Clubs", Icon: Building2 },
    { id: "documents", label: "Documents", Icon: FileText },
    { id: "convocations", label: "Convocations", Icon: CalendarDays },
    { id: "notifications", label: "Notifications", Icon: Bell },
    { id: "settings", label: "Paramètres", Icon: BarChart3 },
  ];

  // Shared filter bar
  function FilterBar({ withSport = true, withStatus = true, withPriority = false, statusOptions = STATUS_OPTIONS }) {
    return (
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="pl-9 pr-4 py-2 rounded-2xl border text-sm bg-white" placeholder="Rechercher..." value={searchQ} onChange={(e) => setSearchQ(e.target.value)} />
        </div>
        {withSport && (
          <select className="rounded-2xl border px-3 py-2 text-sm bg-white" value={filterSport} onChange={(e) => setFilterSport(e.target.value)}>
            <option value="all">Tous les sports</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        )}
        {withStatus && (
          <select className="rounded-2xl border px-3 py-2 text-sm bg-white" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="all">Tous les statuts</option>
            {statusOptions.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
        {withPriority && (
          <select className="rounded-2xl border px-3 py-2 text-sm bg-white" value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)}>
            <option value="all">Toutes les priorités</option>
            {PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        )}
      </div>
    );
  }

  function PageHeader({ title, subtitle, onNew, newLabel }) {
    return (
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
          {subtitle && <p className="text-slate-500 mt-1">{subtitle}</p>}
        </div>
        {onNew && (
          <button onClick={onNew} className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-slate-900 text-white text-sm">
            <Plus className="w-4 h-4" /> {newLabel}
          </button>
        )}
      </div>
    );
  }

  function ActionBtns({ onEdit, onDelete }) {
    return (
      <div className="flex gap-2 shrink-0">
        <button onClick={onEdit} className="px-3 py-2 rounded-xl border bg-white hover:bg-slate-50"><Edit3 className="w-4 h-4" /></button>
        <button onClick={onDelete} className="px-3 py-2 rounded-xl border bg-white hover:bg-red-50 text-red-600"><Trash2 className="w-4 h-4" /></button>
      </div>
    );
  }

  const tableKanbanOptions = [
    { id: "table", label: "Tableau", Icon: ListChecks },
    { id: "kanban", label: "Kanban", Icon: Layers },
  ];
  const listKanbanOptions = [
    { id: "list", label: "Liste", Icon: ListChecks },
    { id: "kanban", label: "Kanban", Icon: Layers },
  ];

  const projectViewOptions = [
    { id: "tree", label: "Arborescence", Icon: FolderKanban },
    ...tableKanbanOptions,
  ];

  const renderProjectKanbanCard = (project) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{project.name}</h3>
          <p className="text-xs text-slate-500 truncate">{sportName(project.sport)}</p>
        </div>
        <ActionBtns onEdit={() => handleEditProject(project)} onDelete={() => requestDelete("project", project)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        <Badge className={badgeClass("priority", project.priority)}>{project.priority}</Badge>
        {project.owner && <Badge>{project.owner}</Badge>}
      </div>
      <ProgressBar value={project.computedTotalProgress || 0} label="Avancement" />
      <div className="flex justify-between text-xs text-slate-500">
        <span>{wsTasks.filter((task) => task.projectId === project.id).length} tâche{wsTasks.filter((task) => task.projectId === project.id).length > 1 ? "s" : ""}</span>
        {project.endDate && <span>{project.endDate}</span>}
      </div>
    </div>
  );

  const renderTaskKanbanCard = (task) => {
    const progress = normalizeTaskProgress(task.progress, task.status);
    return (
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="font-semibold text-sm text-slate-900 truncate">{task.title}</h3>
            <p className="text-xs text-slate-500 truncate">{data.projects.find((project) => project.id === task.projectId)?.name || "Sans projet"}</p>
          </div>
          <ActionBtns onEdit={() => { setForm({ ...task }); setTaskModal({ open: true, item: task }); }} onDelete={() => requestDelete("task", task)} />
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Badge className={badgeClass("priority", task.priority)}>{task.priority}</Badge>
          {task.assignee && <Badge>{task.assignee}</Badge>}
        </div>
        <ProgressBar value={progress} label="Avancement" />
        {(task.startDate || task.endDate) && (
          <p className="text-xs text-slate-500">{task.startDate || "—"} → {task.endDate || "—"}</p>
        )}
      </div>
    );
  };

  const renderAthleteKanbanCard = (athlete) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{athlete.name}</h3>
          <p className="text-xs text-slate-500 truncate">{sportName(athlete.sport)}</p>
        </div>
        <ActionBtns onEdit={() => { setForm({ ...athlete }); setAthleteModal({ open: true, item: athlete }); }} onDelete={() => requestDelete("athlete", athlete)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {athlete.category && <Badge>{athlete.category}</Badge>}
        {athlete.coach && <Badge>{athlete.coach}</Badge>}
      </div>
      {(athlete.email || athlete.phone) && <p className="text-xs text-slate-500 truncate">{athlete.email || athlete.phone}</p>}
    </div>
  );

  const renderClubKanbanCard = (club) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{club.name}</h3>
          <p className="text-xs text-slate-500 truncate">{club.city || sportName(club.sport)}</p>
        </div>
        <ActionBtns onEdit={() => { setForm({ ...club }); setClubModal({ open: true, item: club }); }} onDelete={() => requestDelete("club", club)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        <Badge>{sportName(club.sport)}</Badge>
        {club.delegationSize && <Badge>{club.delegationSize} pers.</Badge>}
      </div>
      {(club.contactName || club.email) && <p className="text-xs text-slate-500 truncate">{club.contactName || club.email}</p>}
    </div>
  );

  const renderDocumentKanbanCard = (doc) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{doc.title}</h3>
          <p className="text-xs text-slate-500 truncate">{doc.url ? "Lien externe" : "Document interne"}</p>
        </div>
        <ActionBtns onEdit={() => { setForm({ ...doc }); setDocModal({ open: true, item: doc }); }} onDelete={() => requestDelete("document", doc)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {doc.type && <Badge>{doc.type}</Badge>}
        <Badge>{sportName(doc.sport)}</Badge>
      </div>
      {doc.notes && <p className="text-xs text-slate-500 line-clamp-2">{doc.notes}</p>}
    </div>
  );

  const renderConvocationKanbanCard = (conv) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{conv.title}</h3>
          <p className="text-xs text-slate-500 truncate">{conv.location || sportName(conv.sport)}</p>
        </div>
        <ActionBtns onEdit={() => { setForm({ ...conv }); setConvModal({ open: true, item: conv }); }} onDelete={() => requestDelete("convocation", conv)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {conv.type && <Badge>{conv.type}</Badge>}
        <Badge>{sportName(conv.sport)}</Badge>
      </div>
      {(conv.date || conv.time) && <p className="text-xs text-slate-500">{conv.date || "—"} {conv.time || ""}</p>}
    </div>
  );

  const renderNotificationKanbanCard = (notif) => (
    <div className="space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-sm text-slate-900 truncate">{notif.title}</h3>
          <p className="text-xs text-slate-500 truncate">{notif.audience || sportName(notif.sport)}</p>
        </div>
        <ActionBtns onEdit={() => { setForm({ ...notif }); setNotifModal({ open: true, item: notif }); }} onDelete={() => requestDelete("notification", notif)} />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {notif.channel && <Badge>{notif.channel}</Badge>}
        <Badge>{sportName(notif.sport)}</Badge>
      </div>
      {notif.sentAt && <p className="text-xs text-slate-500">Envoi : {notif.sentAt}</p>}
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-60 bg-white border-r border-slate-200 flex flex-col shrink-0 sticky top-0 h-screen">
        <div className="px-5 py-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-slate-900 flex items-center justify-center shrink-0">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-bold text-slate-900 leading-none">JAM SaaS</p>
              <p className="text-xs text-slate-500 mt-0.5">v13</p>
            </div>
          </div>
        </div>
        <WorkspaceSelector
          workspaces={data.workspaces || []}
          currentWorkspaceId={currentWsId}
          onChange={switchWorkspace}
          onNew={() => { setWsForm({ color: "#0f172a" }); setWsModal(true); }}
        />
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-auto">
          {navItems.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => { setView(id); resetFilters(); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm transition-colors ${view === id ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
            </button>
          ))}
        </nav>
        <div className="px-5 py-3 border-t border-slate-200 text-xs text-slate-400">
          {wsProjects.length} projets · {wsTasks.length} tâches
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">

        {/* ── DASHBOARD ── */}
        {view === "dashboard" && (
          <div className="p-6 max-w-6xl mx-auto">
            <PageHeader title="Tableau de bord" subtitle="Vue d'ensemble de l'organisation sportive" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <StatCard title="Projets" value={wsProjects.length} subtitle="projets actifs" Icon={FolderKanban} />
              <StatCard title="Tâches" value={totalTasks} subtitle={`${completedTasks} terminées`} Icon={ListChecks} />
              <StatCard title="Athlètes" value={wsAthletes.length} subtitle="inscrits" Icon={Users} />
              <StatCard title="Clubs" value={wsClubs.length} subtitle="clubs suivis" Icon={Building2} />
            </div>
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <Card className="p-5">
                <h2 className="font-semibold mb-4">Avancement global</h2>
                <ProgressBar value={avgProgress} label="Progression moyenne des tâches" />
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="text-center p-3 rounded-2xl bg-slate-50">
                    <p className="text-2xl font-semibold">{wsTasks.filter((t) => t.status === "À faire").length}</p>
                    <p className="text-xs text-slate-500 mt-1">À faire</p>
                  </div>
                  <div className="text-center p-3 rounded-2xl bg-blue-50">
                    <p className="text-2xl font-semibold text-blue-700">{inProgressTasks}</p>
                    <p className="text-xs text-slate-500 mt-1">En cours</p>
                  </div>
                  <div className="text-center p-3 rounded-2xl bg-green-50">
                    <p className="text-2xl font-semibold text-green-700">{completedTasks}</p>
                    <p className="text-xs text-slate-500 mt-1">Terminées</p>
                  </div>
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="font-semibold mb-4">Tâches récentes</h2>
                <div className="space-y-3">
                  {wsTasks.slice(-5).reverse().map((task) => (
                    <div key={task.id} className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{task.title}</p>
                        <p className="text-xs text-slate-500">{task.assignee || "Non assignée"}</p>
                      </div>
                      <Badge className={badgeClass("status", task.status)}>{task.status}</Badge>
                    </div>
                  ))}
                  {!wsTasks.length && <p className="text-sm text-slate-500">Aucune tâche pour l'instant.</p>}
                </div>
              </Card>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="p-5">
                <h2 className="font-semibold mb-3">Sports suivis</h2>
                <div className="space-y-2">
                  {allSports.map((sport) => {
                    const count = wsAthletes.filter((a) => a.sport === sport.id).length;
                    return (
                      <div key={sport.id} className="flex items-center justify-between">
                        <span className="text-sm">{sport.name}</span>
                        <Badge>{count} athlète{count > 1 ? "s" : ""}</Badge>
                      </div>
                    );
                  })}
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="font-semibold mb-3">Statut clubs</h2>
                <div className="space-y-2">
                  {CLUB_STATUS.map((s) => {
                    const count = wsClubs.filter((c) => c.status === s).length;
                    const tone = s === "Validé" ? "Terminé" : s === "Inscrit" ? "En cours" : s === "Invité" ? "En attente" : "À faire";
                    return (
                      <div key={s} className="flex items-center justify-between">
                        <span className="text-sm">{s}</span>
                        <Badge className={badgeClass("status", tone)}>{count}</Badge>
                      </div>
                    );
                  })}
                </div>
              </Card>
              <Card className="p-5">
                <h2 className="font-semibold mb-3">Documents & comm.</h2>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm"><span>Docs internes</span><Badge>{wsDocs.filter((d) => !d.url).length}</Badge></div>
                  <div className="flex justify-between text-sm"><span>Liens externes</span><Badge>{wsDocs.filter((d) => d.url).length}</Badge></div>
                  <div className="flex justify-between text-sm"><span>Convocations</span><Badge>{wsConvocations.length}</Badge></div>
                  <div className="flex justify-between text-sm"><span>Notifications</span><Badge>{wsNotifications.length}</Badge></div>
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* ── PROJECTS ── */}
        {view === "projects" && (
          <div className="p-6 max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Projets</h1>
                <p className="text-slate-500 mt-1">{filteredProjects.length} projet{filteredProjects.length > 1 ? "s" : ""} affiché{filteredProjects.length > 1 ? "s" : ""}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <ViewToggle options={projectViewOptions} value={projectViewMode} onChange={setProjectViewMode} />
                <button onClick={() => setGuidedOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-2xl border border-slate-900 text-slate-900 text-sm font-medium hover:bg-slate-50">
                  <Send className="w-4 h-4" /> Saisie guidée
                </button>
                <button onClick={() => { setForm({ status: "À faire", priority: "Moyenne", sport: "developpe_couche", customFieldValues: {} }); setProjectModal({ open: true, item: null }); }}
                  className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-slate-900 text-white text-sm font-medium">
                  <Plus className="w-4 h-4" /> Nouveau projet
                </button>
              </div>
            </div>
            <FilterBar withPriority={false} />
            {projectViewMode === "tree" ? (
              <>
                <ProjectTree
                  nodes={projectTree}
                  tasks={wsTasks}
                  projects={enrichedProjects}
                  expanded={expanded}
                  setExpanded={setExpanded}
                  onQuickTask={handleQuickTask}
                  onEditProject={handleEditProject}
                  requestDelete={requestDelete}
                  onDuplicate={handleDuplicate}
                  projectCustomFields={projectCustomFields}
                />
                {!filteredProjects.length && <p className="text-center text-slate-500 py-12">Aucun projet trouvé.</p>}
              </>
            ) : projectViewMode === "table" ? (
              <ProjectTable
                projects={filteredProjects}
                tasks={wsTasks}
                onEdit={handleEditProject}
                requestDelete={requestDelete}
                onQuickTask={handleQuickTask}
                config={data.tableConfig?.projects}
                onConfigChange={(next) => setData((prev) => ({ ...prev, tableConfig: { ...(prev.tableConfig || {}), projects: next } }))}
                customFields={legacyProjectCustomFields}
              />
            ) : (
              <KanbanBoard
                rows={filteredProjects}
                statuses={STATUS_OPTIONS}
                onStatusChange={updateProjectStatus}
                renderCard={renderProjectKanbanCard}
                emptyLabel="Aucun projet trouvé."
              />
            )}
          </div>
        )}

        {/* ── TASKS ── */}
        {view === "tasks" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Tâches"
              subtitle={`${filteredTasks.length} tâche${filteredTasks.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ status: "À faire", priority: "Moyenne", progress: 0, customFieldValues: {} }); setTaskModal({ open: true, item: null }); }}
              newLabel="Nouvelle tâche"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={tableKanbanOptions} value={taskViewMode} onChange={setTaskViewMode} />
            </div>
            <FilterBar withSport={false} withPriority />
            {taskViewMode === "table" ? (
              <EntityTable
                rows={filteredTasks}
                nameKey="title"
                emptyLabel="Aucune tâche trouvée."
                builtinCols={[
                  { key: "title", label: "Tâche", type: "texte", sortable: true },
                  { key: "status", label: "Statut", type: "statut", sortable: true, options: STATUS_OPTIONS,
                    render: (t) => <Badge className={badgeClass("status", t.status)}>{t.status}</Badge> },
                  { key: "priority", label: "Priorité", type: "statut", sortable: true, options: PRIORITY_OPTIONS,
                    render: (t) => <Badge className={badgeClass("priority", t.priority)}>{t.priority}</Badge> },
                  { key: "projectId", label: "Projet", type: "texte", sortable: true,
                    accessor: (t) => data.projects.find((p) => p.id === t.projectId)?.name || "—",
                    render: (t) => <span className="text-slate-700">{data.projects.find((p) => p.id === t.projectId)?.name || "—"}</span> },
                  { key: "assignee", label: "Assigné", type: "personne", sortable: true },
                  { key: "progress", label: "Avancement", type: "nombre", sortable: true,
                    accessor: (t) => normalizeTaskProgress(t.progress, t.status),
                    render: (t) => {
                      const p = normalizeTaskProgress(t.progress, t.status);
                      return (
                        <div className="flex items-center gap-2 min-w-32">
                          <div className="flex-1 h-2 rounded-full bg-slate-200 overflow-hidden">
                            <div className={`h-full rounded-full ${progressTone(p)}`} style={{ width: `${p}%` }} />
                          </div>
                          <span className="text-xs font-bold text-slate-700 w-9 text-right">{p}%</span>
                        </div>
                      );
                    } },
                  { key: "startDate", label: "Début", type: "date", sortable: true },
                  { key: "endDate", label: "Échéance", type: "date", sortable: true },
                ]}
                config={data.tableConfig?.tasks}
                onConfigChange={(next) => setData((prev) => ({ ...prev, tableConfig: { ...(prev.tableConfig || {}), tasks: next } }))}
                onEdit={(task) => { setForm({ ...task }); setTaskModal({ open: true, item: task }); }}
                onDelete={(task) => requestDelete("task", task)}
                customFields={legacyTaskCustomFields}
              />
            ) : (
              <KanbanBoard
                rows={filteredTasks}
                statuses={STATUS_OPTIONS}
                onStatusChange={updateTaskStatus}
                renderCard={renderTaskKanbanCard}
                emptyLabel="Aucune tâche trouvée."
              />
            )}
          </div>
        )}

        {/* ── ATHLETES ── */}
        {view === "athletes" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Athlètes"
              subtitle={`${filteredAthletes.length} athlète${filteredAthletes.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ status: "Actif", sport: "developpe_couche" }); setAthleteModal({ open: true, item: null }); }}
              newLabel="Nouvel athlète"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={tableKanbanOptions} value={athleteViewMode} onChange={setAthleteViewMode} />
            </div>
            <FilterBar statusOptions={ATHLETE_STATUS} />
            {athleteViewMode === "table" ? (
              <EntityTable
                rows={filteredAthletes}
                nameKey="name"
                emptyLabel="Aucun athlète trouvé."
                builtinCols={[
                  { key: "name", label: "Athlète", type: "texte", sortable: true },
                  { key: "status", label: "Statut", type: "statut", sortable: true, options: ATHLETE_STATUS,
                    render: (a) => <Badge className={badgeClass("status", a.status === "Actif" ? "En cours" : a.status === "Blessé" ? "En attente" : "À faire")}>{a.status}</Badge> },
                  { key: "sport", label: "Sport", type: "statut", sortable: true,
                    options: data.sports?.map((s) => s.name) || BASE_SPORTS.map((s) => s.name),
                    accessor: (a) => sportName(a.sport),
                    render: (a) => <Badge>{sportName(a.sport)}</Badge> },
                  { key: "category", label: "Catégorie", type: "texte", sortable: true },
                  { key: "coach", label: "Coach", type: "personne", sortable: true },
                  { key: "email", label: "Email", type: "texte", sortable: true },
                  { key: "phone", label: "Téléphone", type: "texte", sortable: true },
                ]}
                config={data.tableConfig?.athletes}
                onConfigChange={(next) => setData((prev) => ({ ...prev, tableConfig: { ...(prev.tableConfig || {}), athletes: next } }))}
                onEdit={(athlete) => { setForm({ ...athlete }); setAthleteModal({ open: true, item: athlete }); }}
                onDelete={(athlete) => requestDelete("athlete", athlete)}
              />
            ) : (
              <KanbanBoard
                rows={filteredAthletes}
                statuses={ATHLETE_STATUS}
                onStatusChange={(id, status) => updateEntityStatus("athletes", id, status)}
                renderCard={renderAthleteKanbanCard}
                emptyLabel="Aucun athlète trouvé."
              />
            )}
          </div>
        )}

        {/* ── CLUBS ── */}
        {view === "clubs" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Clubs"
              subtitle={`${filteredClubs.length} club${filteredClubs.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ status: "À contacter", sport: "developpe_couche" }); setClubModal({ open: true, item: null }); }}
              newLabel="Nouveau club"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={tableKanbanOptions} value={clubViewMode} onChange={setClubViewMode} />
            </div>
            <FilterBar statusOptions={CLUB_STATUS} />
            {clubViewMode === "table" ? (
              <EntityTable
                rows={filteredClubs}
                nameKey="name"
                emptyLabel="Aucun club trouvé."
                builtinCols={[
                  { key: "name", label: "Club", type: "texte", sortable: true },
                  { key: "status", label: "Statut", type: "statut", sortable: true, options: CLUB_STATUS,
                    render: (c) => {
                      const tone = c.status === "Validé" ? "Terminé" : c.status === "Inscrit" ? "En cours" : c.status === "Invité" ? "En attente" : "À faire";
                      return <Badge className={badgeClass("status", tone)}>{c.status}</Badge>;
                    } },
                  { key: "sport", label: "Sport", type: "statut", sortable: true,
                    accessor: (c) => sportName(c.sport),
                    render: (c) => <Badge>{sportName(c.sport)}</Badge> },
                  { key: "city", label: "Ville", type: "texte", sortable: true },
                  { key: "contactName", label: "Contact", type: "personne", sortable: true },
                  { key: "email", label: "Email", type: "texte", sortable: true },
                  { key: "phone", label: "Téléphone", type: "texte", sortable: true },
                  { key: "delegationSize", label: "Délégation", type: "nombre", sortable: true },
                ]}
                config={data.tableConfig?.clubs}
                onConfigChange={(next) => setData((prev) => ({ ...prev, tableConfig: { ...(prev.tableConfig || {}), clubs: next } }))}
                onEdit={(club) => { setForm({ ...club }); setClubModal({ open: true, item: club }); }}
                onDelete={(club) => requestDelete("club", club)}
              />
            ) : (
              <KanbanBoard
                rows={filteredClubs}
                statuses={CLUB_STATUS}
                onStatusChange={(id, status) => updateEntityStatus("clubs", id, status)}
                renderCard={renderClubKanbanCard}
                emptyLabel="Aucun club trouvé."
              />
            )}
          </div>
        )}

        {/* ── DOCUMENTS ── */}
        {view === "documents" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Documents"
              subtitle={`${filteredDocs.length} document${filteredDocs.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ sport: "developpe_couche", type: "Suivi sportif", status: "Brouillon", url: "", content: "" }); setDocModal({ open: true, item: null }); }}
              newLabel="Nouveau document"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={tableKanbanOptions} value={documentViewMode} onChange={setDocumentViewMode} />
            </div>
            <div className="flex flex-wrap gap-3 mb-5">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input className="pl-9 pr-4 py-2 rounded-2xl border text-sm bg-white" placeholder="Rechercher..." value={searchQ} onChange={(e) => setSearchQ(e.target.value)} />
              </div>
              <select className="rounded-2xl border px-3 py-2 text-sm bg-white" value={filterSport} onChange={(e) => setFilterSport(e.target.value)}>
                <option value="all">Tous les sports</option>
                {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <select className="rounded-2xl border px-3 py-2 text-sm bg-white" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                <option value="all">Tous les statuts</option>
                {DOC_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              {DOC_MODES.map((m) => (
                <button key={m} onClick={() => setDocMode(m)}
                  className={`px-3 py-2 rounded-2xl text-sm border ${docMode === m ? "bg-slate-900 text-white border-slate-900" : "bg-white"}`}>
                  {m === "all" ? "Tous" : m === "internal" ? "Internes" : "Liens externes"}
                </button>
              ))}
            </div>
            {documentViewMode === "table" ? (
              <EntityTable
                rows={filteredDocs}
                nameKey="title"
                emptyLabel="Aucun document trouvé."
                builtinCols={[
                  { key: "title", label: "Document", type: "texte", sortable: true },
                  { key: "status", label: "Statut", type: "statut", sortable: true, options: DOC_STATUS,
                    render: (d) => <Badge className={badgeClass("status", d.status === "Publié" || d.status === "Validé" ? "Terminé" : d.status === "À valider" ? "En attente" : d.status === "Archivé" ? "À faire" : "En cours")}>{d.status}</Badge> },
                  { key: "type", label: "Type", type: "statut", sortable: true,
                    render: (d) => d.type ? <Badge>{d.type}</Badge> : <span className="text-slate-400">—</span> },
                  { key: "sport", label: "Sport", type: "statut", sortable: true,
                    accessor: (d) => sportName(d.sport),
                    render: (d) => <Badge>{sportName(d.sport)}</Badge> },
                  { key: "url", label: "Source", type: "texte", sortable: true,
                    accessor: (d) => d.url ? "Externe" : "Interne",
                    render: (d) => d.url
                      ? <a href={d.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 underline truncate max-w-xs inline-block">{d.url}</a>
                      : <Badge className="bg-slate-50 text-slate-600 border-slate-200">Interne</Badge> },
                  { key: "notes", label: "Notes", type: "texte", sortable: true },
                ]}
                config={data.tableConfig?.documents}
                onConfigChange={(next) => setData((prev) => ({ ...prev, tableConfig: { ...(prev.tableConfig || {}), documents: next } }))}
                onEdit={(doc) => { setForm({ ...doc }); setDocModal({ open: true, item: doc }); }}
                onDelete={(doc) => requestDelete("document", doc)}
              />
            ) : (
              <KanbanBoard
                rows={filteredDocs}
                statuses={DOC_STATUS}
                onStatusChange={(id, status) => updateEntityStatus("documents", id, status)}
                renderCard={renderDocumentKanbanCard}
                emptyLabel="Aucun document trouvé."
              />
            )}
          </div>
        )}

        {/* ── CONVOCATIONS ── */}
        {view === "convocations" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Convocations"
              subtitle={`${filteredConvocations.length} convocation${filteredConvocations.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ sport: "football", type: "Match", status: "Brouillon", workspaceId: currentWsId }); setConvModal({ open: true, item: null }); }}
              newLabel="Nouvelle convocation"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={listKanbanOptions} value={convocationViewMode} onChange={setConvocationViewMode} />
            </div>
            <FilterBar statusOptions={COMM_STATUS} />
            {convocationViewMode === "list" ? (
              <div className="space-y-3">
                {filteredConvocations.map((conv) => (
                  <Card key={conv.id} className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="font-semibold">{conv.title}</h3>
                          <Badge className={badgeClass("status", conv.status === "Envoyée" ? "Terminé" : conv.status === "Prêt à envoyer" ? "En cours" : "À faire")}>{conv.status}</Badge>
                          {conv.type && <Badge>{conv.type}</Badge>}
                          <Badge>{sportName(conv.sport)}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-slate-500 mt-1">
                          {conv.date && <span>Date : {conv.date}</span>}
                          {conv.time && <span>Heure : {conv.time}</span>}
                          {conv.location && <span>Lieu : {conv.location}</span>}
                          {conv.attachmentTitle && <span>PJ : {conv.attachmentTitle}</span>}
                        </div>
                        {conv.message && <p className="text-sm text-slate-600 mt-2 line-clamp-2">{conv.message}</p>}
                      </div>
                      <ActionBtns
                        onEdit={() => { setForm({ ...conv }); setConvModal({ open: true, item: conv }); }}
                        onDelete={() => requestDelete("convocation", conv)}
                      />
                    </div>
                  </Card>
                ))}
                {!filteredConvocations.length && <p className="text-center text-slate-500 py-12">Aucune convocation.</p>}
              </div>
            ) : (
              <KanbanBoard
                rows={filteredConvocations}
                statuses={COMM_STATUS}
                onStatusChange={(id, status) => updateEntityStatus("convocations", id, status)}
                renderCard={renderConvocationKanbanCard}
                emptyLabel="Aucune convocation."
              />
            )}
          </div>
        )}

        {/* ── NOTIFICATIONS ── */}
        {view === "notifications" && (
          <div className="p-6 max-w-7xl mx-auto">
            <PageHeader
              title="Notifications"
              subtitle={`${filteredNotifications.length} notification${filteredNotifications.length > 1 ? "s" : ""}`}
              onNew={() => { setForm({ sport: "developpe_couche", channel: "Email", status: "Brouillon", workspaceId: currentWsId }); setNotifModal({ open: true, item: null }); }}
              newLabel="Nouvelle notification"
            />
            <div className="-mt-4 mb-5 flex justify-end">
              <ViewToggle options={listKanbanOptions} value={notificationViewMode} onChange={setNotificationViewMode} />
            </div>
            <FilterBar statusOptions={COMM_STATUS} />
            {notificationViewMode === "list" ? (
              <div className="space-y-3">
                {filteredNotifications.map((notif) => (
                  <Card key={notif.id} className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h3 className="font-semibold">{notif.title}</h3>
                          <Badge className={badgeClass("status", notif.status === "Envoyée" ? "Terminé" : notif.status === "Prêt à envoyer" ? "En cours" : "À faire")}>{notif.status}</Badge>
                          {notif.channel && <Badge>{notif.channel}</Badge>}
                          <Badge>{sportName(notif.sport)}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-slate-500 mt-1">
                          {notif.audience && <span>Audience : {notif.audience}</span>}
                          {notif.sentAt && <span>Envoyée le : {notif.sentAt}</span>}
                          {notif.attachmentTitle && <span>PJ : {notif.attachmentTitle}</span>}
                        </div>
                        {notif.message && <p className="text-sm text-slate-600 mt-2 line-clamp-2">{notif.message}</p>}
                      </div>
                      <ActionBtns
                        onEdit={() => { setForm({ ...notif }); setNotifModal({ open: true, item: notif }); }}
                        onDelete={() => requestDelete("notification", notif)}
                      />
                    </div>
                  </Card>
                ))}
                {!filteredNotifications.length && <p className="text-center text-slate-500 py-12">Aucune notification.</p>}
              </div>
            ) : (
              <KanbanBoard
                rows={filteredNotifications}
                statuses={COMM_STATUS}
                onStatusChange={(id, status) => updateEntityStatus("notifications", id, status)}
                renderCard={renderNotificationKanbanCard}
                emptyLabel="Aucune notification."
              />
            )}
          </div>
        )}

        {/* ── SETTINGS ── */}
        {view === "settings" && (
          <div className="p-6 max-w-4xl mx-auto">
            <PageHeader title="Paramètres" />

            <Card className="p-6 mb-6 bg-slate-50/60">
              <h2 className="font-semibold text-base mb-2">Colonnes personnalisées</h2>
              <p className="text-sm text-slate-600">
                Les colonnes personnalisées se gèrent maintenant directement depuis chaque vue tableau (Projets, Tâches, Athlètes, Clubs, Documents).
                Clique sur l'icône <span className="inline-flex items-center justify-center w-5 h-5 rounded bg-white border align-middle">+</span> en bout de rangée d'en-têtes, ou sur le menu d'une colonne existante (« Ajouter à gauche / à droite »).
              </p>
            </Card>

            <Card className="p-6">
              <h2 className="font-semibold text-lg mb-4">Sports</h2>
              <div className="space-y-2 mb-4">
                {allSports.map((sport) => (
                  <div key={sport.id} className="flex items-center justify-between p-3 border rounded-2xl">
                    <span className="text-sm font-medium">{sport.name}</span>
                    {data.customSports.find((s) => s.id === sport.id) ? (
                      <button onClick={() => upd("customSports", (arr) => arr.filter((s) => s.id !== sport.id))}
                        className="px-2 py-1 rounded-xl border hover:bg-red-50 text-red-600"><Trash2 className="w-3 h-3" /></button>
                    ) : (
                      <Badge className="bg-slate-50 text-slate-500 border-slate-200">Intégré</Badge>
                    )}
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input className="flex-1 rounded-2xl border px-4 py-2 text-sm" placeholder="Nom du nouveau sport..."
                  value={newSportName} onChange={(e) => setNewSportName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addSport()} />
                <button onClick={addSport} className="px-4 py-2 rounded-2xl bg-slate-900 text-white text-sm">Ajouter</button>
              </div>
            </Card>
          </div>
        )}
      </main>

      {/* ===== MODALS ===== */}

      {/* Project */}
      <Modal open={projectModal.open} title={projectModal.item ? "Modifier le projet" : "Nouveau projet"}
        onClose={() => { setProjectModal({ open: false, item: null }); setForm({}); }} onSave={saveProject}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Nom du projet *" value={form.name || ""} onChange={(e) => f("name", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Responsable" value={form.owner || ""} onChange={(e) => f("owner", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-20" placeholder="Description" value={form.description || ""} onChange={(e) => f("description", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.parentId || ""} onChange={(e) => f("parentId", e.target.value || null)}>
            <option value="">Pas de projet parent</option>
            {data.projects.filter((p) => p.id !== form.id).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "À faire"} onChange={(e) => f("status", e.target.value)}>
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.priority || "Moyenne"} onChange={(e) => f("priority", e.target.value)}>
            {PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <input type="date" className="w-full rounded-2xl border px-4 py-3" value={form.startDate || ""} onChange={(e) => f("startDate", e.target.value)} />
          <input type="date" className="w-full rounded-2xl border px-4 py-3" value={form.endDate || ""} onChange={(e) => f("endDate", e.target.value)} />
        </div>
        {projectCustomFields.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium text-slate-700 mb-3">Champs personnalisés</p>
            <CustomFieldsEditor fields={projectCustomFields} values={form.customFieldValues} onChange={fcf} />
          </div>
        )}
      </Modal>

      {/* Task */}
      <Modal open={taskModal.open} title={taskModal.item ? "Modifier la tâche" : "Nouvelle tâche"}
        onClose={() => { setTaskModal({ open: false, item: null }); setForm({}); }} onSave={saveTask}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Titre *" value={form.title || ""} onChange={(e) => f("title", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-16" placeholder="Description" value={form.description || ""} onChange={(e) => f("description", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Assigné à" value={form.assignee || ""} onChange={(e) => f("assignee", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.projectId || ""} onChange={(e) => f("projectId", e.target.value)}>
            <option value="">Projet</option>
            {data.projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "À faire"} onChange={(e) => f("status", e.target.value)}>
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.priority || "Moyenne"} onChange={(e) => f("priority", e.target.value)}>
            {PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
          <input type="date" className="w-full rounded-2xl border px-4 py-3" value={form.startDate || ""} onChange={(e) => f("startDate", e.target.value)} />
          <input type="date" className="w-full rounded-2xl border px-4 py-3" value={form.endDate || ""} onChange={(e) => f("endDate", e.target.value)} />
          <div className="md:col-span-2">
            <label className="block text-sm text-slate-700 mb-2">Progression : <span className="font-semibold">{form.progress || 0}%</span></label>
            <input type="range" min="0" max="100" className="w-full accent-slate-900" value={form.progress || 0} onChange={(e) => f("progress", Number(e.target.value))} />
          </div>
        </div>
        {taskCustomFields.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium text-slate-700 mb-3">Champs personnalisés</p>
            <CustomFieldsEditor fields={taskCustomFields} values={form.customFieldValues} onChange={fcf} />
          </div>
        )}
      </Modal>

      {/* Athlete */}
      <Modal open={athleteModal.open} title={athleteModal.item ? "Modifier l'athlète" : "Nouvel athlète"}
        onClose={() => { setAthleteModal({ open: false, item: null }); setForm({}); }} onSave={saveAthlete}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Nom complet *" value={form.name || ""} onChange={(e) => f("name", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Catégorie (ex : -88 kg, U13…)" value={form.category || ""} onChange={(e) => f("category", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Coach" value={form.coach || ""} onChange={(e) => f("coach", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "Actif"} onChange={(e) => f("status", e.target.value)}>
            {ATHLETE_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input type="email" className="w-full rounded-2xl border px-4 py-3" placeholder="Email" value={form.email || ""} onChange={(e) => f("email", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Téléphone" value={form.phone || ""} onChange={(e) => f("phone", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-16" placeholder="Notes" value={form.notes || ""} onChange={(e) => f("notes", e.target.value)} />
        </div>
      </Modal>

      {/* Club */}
      <Modal open={clubModal.open} title={clubModal.item ? "Modifier le club" : "Nouveau club"}
        onClose={() => { setClubModal({ open: false, item: null }); setForm({}); }} onSave={saveClub}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Nom du club *" value={form.name || ""} onChange={(e) => f("name", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Ville" value={form.city || ""} onChange={(e) => f("city", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Nom du contact" value={form.contactName || ""} onChange={(e) => f("contactName", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "À contacter"} onChange={(e) => f("status", e.target.value)}>
            {CLUB_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input type="email" className="w-full rounded-2xl border px-4 py-3" placeholder="Email" value={form.email || ""} onChange={(e) => f("email", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Téléphone" value={form.phone || ""} onChange={(e) => f("phone", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Taille délégation" value={form.delegationSize || ""} onChange={(e) => f("delegationSize", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-16" placeholder="Notes" value={form.notes || ""} onChange={(e) => f("notes", e.target.value)} />
        </div>
      </Modal>

      {/* Document */}
      <Modal open={docModal.open} title={docModal.item ? "Modifier le document" : "Nouveau document"}
        onClose={() => { setDocModal({ open: false, item: null }); setForm({}); }} onSave={saveDoc}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Titre *" value={form.title || ""} onChange={(e) => f("title", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Type (Match, Suivi sportif…)" value={form.type || ""} onChange={(e) => f("type", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "Brouillon"} onChange={(e) => f("status", e.target.value)}>
            {DOC_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="URL (laisser vide = document interne)" value={form.url || ""} onChange={(e) => f("url", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-20" placeholder="Contenu (si document interne)" value={form.content || ""} onChange={(e) => f("content", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-16" placeholder="Notes" value={form.notes || ""} onChange={(e) => f("notes", e.target.value)} />
        </div>
      </Modal>

      {/* Convocation */}
      <Modal open={convModal.open} title={convModal.item ? "Modifier la convocation" : "Nouvelle convocation"}
        onClose={() => { setConvModal({ open: false, item: null }); setForm({}); }} onSave={saveConv}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Titre *" value={form.title || ""} onChange={(e) => f("title", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Type (Match, Entraînement…)" value={form.type || ""} onChange={(e) => f("type", e.target.value)} />
          <input type="date" className="w-full rounded-2xl border px-4 py-3" value={form.date || ""} onChange={(e) => f("date", e.target.value)} />
          <input type="time" className="w-full rounded-2xl border px-4 py-3" value={form.time || ""} onChange={(e) => f("time", e.target.value)} />
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Lieu" value={form.location || ""} onChange={(e) => f("location", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "Brouillon"} onChange={(e) => f("status", e.target.value)}>
            {COMM_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Pièce jointe (titre)" value={form.attachmentTitle || ""} onChange={(e) => f("attachmentTitle", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-20" placeholder="Message" value={form.message || ""} onChange={(e) => f("message", e.target.value)} />
        </div>
      </Modal>

      {/* Notification */}
      <Modal open={notifModal.open} title={notifModal.item ? "Modifier la notification" : "Nouvelle notification"}
        onClose={() => { setNotifModal({ open: false, item: null }); setForm({}); }} onSave={saveNotif}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Titre *" value={form.title || ""} onChange={(e) => f("title", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.sport || ""} onChange={(e) => f("sport", e.target.value)}>
            <option value="">Sport</option>
            {allSports.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <select className="w-full rounded-2xl border px-4 py-3" value={form.channel || "Email"} onChange={(e) => f("channel", e.target.value)}>
            <option value="Email">Email</option>
            <option value="SMS">SMS</option>
            <option value="Push">Push</option>
            <option value="WhatsApp">WhatsApp</option>
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Audience cible" value={form.audience || ""} onChange={(e) => f("audience", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.status || "Brouillon"} onChange={(e) => f("status", e.target.value)}>
            {COMM_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <input className="w-full rounded-2xl border px-4 py-3" placeholder="Pièce jointe (titre)" value={form.attachmentTitle || ""} onChange={(e) => f("attachmentTitle", e.target.value)} />
          <input type="date" className="w-full rounded-2xl border px-4 py-3" placeholder="Date d'envoi" value={form.sentAt || ""} onChange={(e) => f("sentAt", e.target.value)} />
          <textarea className="w-full rounded-2xl border px-4 py-3 md:col-span-2 resize-none h-20" placeholder="Message" value={form.message || ""} onChange={(e) => f("message", e.target.value)} />
        </div>
      </Modal>

      {/* Custom Field */}
      <Modal open={cfModal.open} title={cfModal.item ? "Modifier le champ" : "Nouveau champ personnalisé"}
        onClose={() => { setCfModal({ open: false, item: null }); setForm({}); }} onSave={saveCF}>
        <div className="grid md:grid-cols-2 gap-4">
          <input className="w-full rounded-2xl border px-4 py-3 md:col-span-2" placeholder="Nom du champ *" value={form.name || ""} onChange={(e) => f("name", e.target.value)} />
          <select className="w-full rounded-2xl border px-4 py-3" value={form.type || "texte"} onChange={(e) => f("type", e.target.value)}>
            {CUSTOM_FIELD_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <div className="flex flex-col gap-2 justify-center">
            <p className="text-sm text-slate-700 font-medium">Appliquer à :</p>
            {["projects", "tasks"].map((target) => (
              <label key={target} className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox"
                  checked={(form.appliesTo || []).includes(target)}
                  onChange={(e) => {
                    const cur = form.appliesTo || [];
                    f("appliesTo", e.target.checked ? [...cur, target] : cur.filter((x) => x !== target));
                  }} />
                {target === "projects" ? "Projets" : "Tâches"}
              </label>
            ))}
          </div>
        </div>
      </Modal>

      {/* Guided input panel */}
      <GuidedInputPanel
        open={guidedOpen}
        onClose={() => setGuidedOpen(false)}
        allSports={allSports}
        projects={wsProjects}
        onSave={handleGuidedSave}
      />

      {/* Workspace creation modal */}
      {wsModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Nouvel espace de travail</h3>
              <button onClick={() => { setWsModal(false); setWsForm({}); }} className="text-slate-400 hover:text-slate-700"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-800 mb-2">Nom *</label>
                <input autoFocus className="w-full rounded-2xl border px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                  placeholder="ex : Mon équipe" value={wsForm.name || ""} onChange={(e) => setWsForm((p) => ({ ...p, name: e.target.value }))} />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-800 mb-2">Couleur</label>
                <div className="flex gap-2 flex-wrap">
                  {["#0f172a","#7c3aed","#059669","#dc2626","#d97706","#2563eb","#db2777"].map((c) => (
                    <button key={c} onClick={() => setWsForm((p) => ({ ...p, color: c }))}
                      className={`w-8 h-8 rounded-lg border-2 ${wsForm.color === c ? "border-slate-900 scale-110" : "border-transparent"} transition-all`}
                      style={{ backgroundColor: c }} />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <button onClick={() => { setWsModal(false); setWsForm({}); }} className="px-4 py-2 rounded-2xl border text-sm">Annuler</button>
              <button onClick={saveWorkspace} className="px-4 py-2 rounded-2xl bg-slate-900 text-white text-sm font-semibold">Créer</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {deleteConfirm.open && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-2xl bg-red-100"><AlertTriangle className="w-5 h-5 text-red-600" /></div>
              <h3 className="text-lg font-semibold">Confirmer la suppression</h3>
            </div>
            <p className="text-slate-600 mb-6">
              Supprimer <span className="font-medium">"{deleteConfirm.item?.name || deleteConfirm.item?.title}"</span> ? Cette action est irréversible.
            </p>
            <div className="flex justify-end gap-2">
              <button onClick={() => setDeleteConfirm({ open: false, type: null, item: null })} className="px-4 py-2 rounded-2xl border">Annuler</button>
              <button onClick={confirmDelete} className="px-4 py-2 rounded-2xl bg-red-600 text-white">Supprimer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
